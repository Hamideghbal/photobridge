'use strict';
const path=require('node:path');
const {normalizeSettings}=require('./alert-settings.cjs');
class AlertWindow {
 constructor({BrowserWindow,ipcMain,store,getAccount,open,getWorkArea=()=>({x:0,y:0,width:1920,height:1080})}){
  Object.assign(this,{BrowserWindow,ipcMain,store,getAccount,open,getWorkArea});this.window=null;this.items=[];this.account=null;this.ack=null;this.settingsOnly=false;
  const valid=event=>this.window&&!this.window.isDestroyed()&&event.sender===this.window.webContents;
  ipcMain.handle('lab-alert-layout',(event,height)=>{if(!valid(event))throw Error('invalid_sender');const area=this.getWorkArea(),h=Math.max(220,Math.min(640,area.height-80,Number(height)||300)),w=Math.min(420,area.width-40);this.window.setContentSize?.(w,Math.ceil(h));const bounds=this.window.getBounds?.();if(bounds)this.window.setPosition?.(Math.max(area.x+8,area.x+area.width-bounds.width-20),Math.max(area.y+8,area.y+area.height-bounds.height-20));return h});
  ipcMain.handle('lab-alert-state',event=>{if(!valid(event))throw Error('invalid_sender');return this.state()});
  ipcMain.handle('lab-alert-save',(event,value)=>{if(!valid(event))throw Error('invalid_sender');const settings=normalizeSettings(value);store.set(this.settingsKey(),settings);return settings});
  ipcMain.handle('lab-alert-ack',(event,ids)=>{if(!valid(event))throw Error('invalid_sender');return this.accept(ids,false)});
  ipcMain.handle('lab-alert-open',(event,ids)=>{if(!valid(event))throw Error('invalid_sender');return this.accept(ids,true)});
 }
 settingsKey(){return 'nativeAlertSettings:'+(this.getAccount()||'default');}
 state(){return {items:this.items,settings:normalizeSettings(this.store.get(this.settingsKey())),settingsOnly:this.settingsOnly};}
 ensure(){
  if(this.window&&!this.window.isDestroyed())return this.window;
  const win=this.window=new this.BrowserWindow({width:420,height:300,minWidth:380,minHeight:240,useContentSize:true,resizable:false,maximizable:false,title:'اعلان‌ها · PhotoBridge Lab',show:false,alwaysOnTop:true,autoHideMenuBar:true,backgroundColor:'#f5f7fb',webPreferences:{preload:path.join(__dirname,'alert-preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,autoplayPolicy:'no-user-gesture-required',backgroundThrottling:false}});
  win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  win.webContents.on('will-navigate',e=>e.preventDefault());
  win.on('close',e=>{e.preventDefault();if(this.items.length){win.show();win.focus()}else win.hide()});
  win.once('ready-to-show',()=>{if(this.items.length||this.settingsOnly){win.show();win.focus()}});
  win.loadFile(path.join(__dirname,'alert.html')).catch(()=>{if(this.window===win)this.window=null;win.destroy()});
  return win;
 }
 present(options,_onOpen,ack,account){
  if(this.getAccount()!==account)return;
  const previous=this.items.map(x=>x.id).join('|');this.items=options.items||[];this.account=account;this.ack=ack;this.settingsOnly=false;
  const win=this.ensure();if(previous!==this.items.map(x=>x.id).join('|')){win.webContents.send('lab-alert-change');win.show();win.restore();win.focus();win.flashFrame(true)}
 }
 showSettings(){this.settingsOnly=!this.items.length;const win=this.ensure();win.webContents.send('lab-alert-change');win.show();win.restore();win.focus();}
 async accept(ids,open){
  if(this.account&&this.account!==this.getAccount()){this.dismiss();return false;}
  if(open)await this.open();
  const shown=new Set(Array.isArray(ids)?ids:[]),accepted=this.items.filter(x=>shown.has(x.id)).map(x=>x.id);
  this.ack?.(accepted);this.items=this.items.filter(x=>!shown.has(x.id));
  if(this.window&&!this.window.isDestroyed()){this.window.flashFrame(false);if(!this.items.length)this.window.hide();this.window.webContents.send('lab-alert-change')}
  return true;
 }
 dismiss(){this.items=[];this.ack=null;this.account=null;this.settingsOnly=false;if(this.window&&!this.window.isDestroyed()){this.window.webContents.send('lab-alert-change');this.window.hide();this.window.flashFrame(false)}}
 destroy(){this.window?.destroy();this.window=null;for(const name of ['state','save','ack','open','layout'])this.ipcMain.removeHandler('lab-alert-'+name)}
}
module.exports={AlertWindow};
