'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const ROOT_FILE='equipment-rental-portal.html';
const MAX_FILE_BYTES=20e6;
function validRoot(root){try{return Boolean(root&&fs.existsSync(path.join(root,ROOT_FILE))&&fs.statSync(path.join(root,ROOT_FILE)).isFile())}catch{return false}}
function criticalMatches(root,manifest){if(!validRoot(root))return false;try{for(const name of [ROOT_FILE,'desktop-overlay.js']){const f=manifest.files.find(x=>x.name===name);if(!f)continue;const file=path.join(root,name);if(!fs.existsSync(file)||hash(fs.readFileSync(file))!==f.sha256)return false}return true}catch{return false}}
function cleanup(directory,keep){try{if(!fs.existsSync(directory))return;for(const ent of fs.readdirSync(directory,{withFileTypes:true})){if(!ent.isDirectory())continue;const full=path.join(directory,ent.name);if(ent.name.endsWith('.partial')){fs.rmSync(full,{recursive:true,force:true});continue}if(/^[a-f0-9]{64}$/.test(ent.name)&&!keep.has(full))fs.rmSync(full,{recursive:true,force:true})}}catch{}}
async function fetchManifest(request,timeout){
 const endpoints=['/api/desktop-ui/store-manifest','/api/rental/desktop-ui-manifest'];let last=null;
 for(const endpoint of endpoints){try{const response=await request(endpoint,{signal:AbortSignal.timeout(Math.min(Math.max(timeout,8000),15000)),anonymous:true,headers:{'Cache-Control':'no-cache','Pragma':'no-cache'}});if(response.ok)return await response.json();last=Error(response.status===401?'login_required':'ui_manifest_unavailable_'+response.status);if(![401,403,404,503].includes(response.status))throw last}catch(e){last=e}}
 throw last||Error('ui_manifest_unavailable');
}
async function readRemoteFile(request,url,remaining){const signal=AbortSignal.timeout(Math.max(5000,Math.min(30000,remaining)));const r=await request(url,{signal,anonymous:true,headers:{'Cache-Control':'no-cache','Pragma':'no-cache'}});if(!r.ok)throw Error('update_download_failed');if(Number(r.headers?.get('content-length'))>MAX_FILE_BYTES)throw Error('update_too_large');const chunks=[];let length=0;for await(const chunk of r.body){length+=chunk.length;if(length>MAX_FILE_BYTES)throw Error('update_too_large');chunks.push(chunk)}return Buffer.concat(chunks)}
async function updateUi({store,request,bundled,directory,timeout=120000,onProgress=()=>{}}){
 const manifest=await fetchManifest(request,timeout);
 if(manifest.protocol!==1)throw Error('native_update_required');
 if(!/^[a-f0-9]{64}$/.test(manifest.build)||!Array.isArray(manifest.files)||manifest.files.length>1800||!manifest.files.some(f=>f.name===ROOT_FILE))throw Error('invalid_ui_manifest');
 if(hash(JSON.stringify(manifest.files))!==manifest.build)throw Error('ui_manifest_hash_mismatch');
 if(manifest.build===store.get('uiFailedBuild'))throw Error('ui_build_quarantined');
 const target=path.join(directory,manifest.build);
 if(manifest.build===store.get('uiBuild')&&criticalMatches(target,manifest)){store.set('uiLastCheckedAt',new Date().toISOString());return false}
 const previousRoot=validRoot(store.get('uiRoot'))?store.get('uiRoot'):null,previousBuild=store.get('uiBuild')||null;
 const staging=target+'.partial';fs.rmSync(staging,{recursive:true,force:true});fs.mkdirSync(staging,{recursive:true});let count=0;const names=new Set(),deadline=Date.now()+Math.max(timeout,30000);
 try{
  for(const f of manifest.files){
   if(Date.now()>=deadline)throw Error('ui_update_timeout');
   if(!/^[a-zA-Z0-9_./-]+$/.test(f.name)||f.name.startsWith('/')||f.name.includes('..')||names.has(f.name)||f.url!=='/desktop-ui/'+f.name||!/^[a-f0-9]{64}$/.test(f.sha256))throw Error('invalid_update_path');names.add(f.name);
   const file=path.join(staging,f.name);let content;
   for(const old of [previousRoot,bundled].filter(Boolean)){const candidate=path.join(old,f.name);if(fs.existsSync(candidate)&&fs.statSync(candidate).isFile()){const bytes=fs.readFileSync(candidate);if(hash(bytes)===f.sha256){content=bytes;break}}}
   if(!content)content=await readRemoteFile(request,f.url,deadline-Date.now());
   if(content.length>MAX_FILE_BYTES||hash(content)!==f.sha256)throw Error('update_hash_mismatch');
   fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,content);onProgress(++count,manifest.files.length);
  }
  // Backward compatibility with older server manifests: keep the bundled overlay only when
  // the server did not publish an updatable desktop-overlay.js yet.
  if(!names.has('desktop-overlay.js')&&fs.existsSync(path.join(bundled,'desktop-overlay.js')))fs.copyFileSync(path.join(bundled,'desktop-overlay.js'),path.join(staging,'desktop-overlay.js'));
  if(!validRoot(staging))throw Error('ui_root_missing');
  fs.rmSync(target,{recursive:true,force:true});fs.renameSync(staging,target);
  store.transaction(()=>{store.set('uiPreviousRoot',previousRoot);store.set('uiPreviousBuild',previousBuild);store.set('uiRoot',target);store.set('uiBuild',manifest.build);store.set('uiDownloadedAt',new Date().toISOString());store.set('uiLastCheckedAt',new Date().toISOString());store.set('updateError',null)});
  cleanup(directory,new Set([target,previousRoot].filter(Boolean)));return true;
 }catch(e){fs.rmSync(staging,{recursive:true,force:true});store.set('uiLastCheckedAt',new Date().toISOString());throw e}
}
module.exports={updateUi};
