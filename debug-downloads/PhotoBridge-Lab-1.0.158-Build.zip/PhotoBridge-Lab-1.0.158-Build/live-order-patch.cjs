'use strict';
function patchOrderLive(source){
 // R1961: R1944+ uses the authoritative paged server endpoint and keeps
 // all-status counts and total pages in its React state. The legacy PB1468
 // replacement below fetches /api/lab/orders and overwrites that entire
 // component from pbLiveOrders through Ye, silently destroying its pagination.
 // Preserve the new component while retaining finance live updates and
 // optimistic document-revision guards required by the native workstation.
 if(source.includes('/* PB1944 server-paged lab queue */')){
  if(source.includes('const pbNativeOpeningPage='))return source;
  const guarded=source
   .replace('new Error(p.error||"request_failed")','new Error(p.message||p.error||"request_failed")')
   .replace('JSON.stringify({status:nt,note:xt||null})','JSON.stringify({status:nt,note:xt||null,expectedUpdatedAt:le.updated_at,expectedRevision:le.document_revision})')
   .replace('JSON.stringify({stage:nt})','JSON.stringify({stage:nt,expectedUpdatedAt:le.updated_at,expectedRevision:le.document_revision})');
  if(!guarded.includes('paged=1&mode=')||!guarded.includes('r1944SetCounts')||
      !guarded.includes('r1944SetPages')||!guarded.includes('r1944SetTotal'))
   throw Error('native_paged_order_contract_missing');
  // Hide only the buttons. Keep the search and server total in the toolbar.
  const withPager=guarded.replace(/\be\.jsxs\("div",\{className:"r1944Pager",children:\[/g,
   'r1944Total>=10&&$&');
  const {patchNativeQueuePresentation,removeConfirmedOrderExitWait}=require('./native-queue-presentation.cjs');
  const liveHelpers=source.includes('function pb1468BrowserEvents')?'':
   require('./lab-realtime.cjs').subscribeLabEvents.toString().replace('function subscribeLabEvents','function pb1468SubscribeLabEvents')+
   '\n'+browserEvents.toString().replace('function browserEvents','function pb1468BrowserEvents');
  return upgradeFinanceLive(patchFinanceLive(removeConfirmedOrderExitWait(patchNativeOrderStages(patchNativeQueuePresentation(withPager)))))+
   '\n/* PB1961 preserve native Lab server pagination */\n'+liveHelpers;
 }
 if(source.includes('/* PB1468 shared document isolation */'))return upgradeFinanceLive(source);
 const start=source.indexOf('const pbLiveOrders=')>=0?source.indexOf('const pbLiveOrders='):source.indexOf('const pb1465List=')>=0?source.indexOf('const pb1465List='):source.indexOf('const ye=()=>Me("/api/lab/orders")');
 const end=start<0?-1:source.indexOf('const Ye=',start);if(start<0||end<0||end-start>6000)throw Error('lab_live_refresh_bundle_incompatible');
 const replacement=`/* PB1468 shared document isolation */const pbLiveOrders=x.useRef({seq:0,active:true}),ye=()=>{const seq=++pbLiveOrders.current.seq;const recovery=new URLSearchParams(location.search).get('recoveredOrder');return Me('/api/lab/orders'+(recovery?'?recovery='+encodeURIComponent(recovery):'')).then(data=>{if(pbLiveOrders.current.active&&seq===pbLiveOrders.current.seq)f((data.orders||[]).filter(row=>String(row.mode||'print')===o));});};x.useEffect(()=>{pbLiveOrders.current.active=true;let busy=false,closed=false,rerun=false;const refresh=async(event)=>{if(closed||document.hidden)return;if(busy){if(event?.type==='document.changed'||event?.type==='photobridge-lab-orders-changed')rerun=true;return;}busy=true;try{await ye();}catch{}finally{busy=false;if(rerun){rerun=false;void refresh();}}};const visible=()=>{if(!document.hidden)void refresh();};void refresh();const timer=setInterval(refresh,3000);const stream=pb1468BrowserEvents(t?.id,()=>{void refresh({type:'document.changed'});window.dispatchEvent(new CustomEvent('photobridge-finance-changed'));});window.addEventListener('photobridge-lab-orders-changed',refresh);window.addEventListener('focus',visible);document.addEventListener('visibilitychange',visible);return()=>{stream?.stop();closed=true;pbLiveOrders.current.active=false;pbLiveOrders.current.seq++;clearInterval(timer);window.removeEventListener('photobridge-lab-orders-changed',refresh);window.removeEventListener('focus',visible);document.removeEventListener('visibilitychange',visible);};},[a,o,t?.id]);`;
 source=source.slice(0,start)+replacement+source.slice(end);source=source.replace('new Error(p.error||"request_failed")','new Error(p.message||p.error||"request_failed")');source=source.replace('JSON.stringify({status:nt,note:xt||null})','JSON.stringify({status:nt,note:xt||null,expectedUpdatedAt:le.updated_at,expectedRevision:le.document_revision})').replace('JSON.stringify({stage:nt})','JSON.stringify({stage:nt,expectedUpdatedAt:le.updated_at,expectedRevision:le.document_revision})');return upgradeFinanceLive(patchFinanceLive(source))+'\n'+require('./lab-realtime.cjs').subscribeLabEvents.toString().replace('function subscribeLabEvents','function pb1468SubscribeLabEvents')+'\n'+browserEvents.toString().replace('function browserEvents','function pb1468BrowserEvents');
}

function patchNativeOrderStages(source){
 const start=source.indexOf('It=async(le,nt,xt)=>'),end=source.indexOf(',aa=async',start);
 if(start<0||end<0||end-start>12000)return source;
 const handlers=source.slice(start,end)
  .replace('nt==="printing"&&!await pb1450AllowStage(le)','nt==="printing"&&!le.invoice_id&&!await pb1450AllowStage(le)')
  .replace('gn=async le=>{if(!await pb1450AllowStage(le))','gn=async le=>{if(!le.invoice_id&&!await pb1450AllowStage(le))')
  .replace(`if(typeof window!=="undefined"&&window.pbNativeStorage){const fresh=(await Me('/api/lab/orders/'+encodeURIComponent(le.id))).order;`, `if(!le.invoice_id&&typeof window!=="undefined"&&window.pbNativeStorage){const fresh=(await Me('/api/lab/orders/'+encodeURIComponent(le.id))).order;`)
  .replace('un=async le=>{if(!await pb1450AllowStage(le))','un=async le=>{if(!le.invoice_id&&!await pb1450AllowStage(le))')
  .replace('["printing","binding","ready","completed"].includes(nt)&&!await pb1450AllowStage(le)','["printing","binding","ready","completed"].includes(nt)&&!le.invoice_id&&!await pb1450AllowStage(le)');
 return source.slice(0,start)+handlers+source.slice(end);
}

function patchNativeFinanceOverview(source){
 const invoice='const Ot=await Me(ke);';
 const parallel='Me(`/api/lab/finance/summary?${At.toString()}`),extraPath?Me(extraPath):Promise.resolve(null)';
 const viewGuard=/pb1569LoadedFinanceView\.current=w;\s*const endpoint=/;
 const finance=source.indexOf('function ub({role:t');
 const start=source.indexOf(invoice,finance),summary=source.indexOf(parallel,start);
 const tabMatch=summary<0?null:viewGuard.exec(source.slice(summary,summary+14000));
 const tabs=tabMatch?summary+tabMatch.index:-1;
 if(finance<0||start<0||summary<0||tabs<0||tabs-start>14000||source.includes('pbNativeOverview'))return source;
 const end=tabs+tabMatch[0].length;
 const body=source.slice(start,end)
  .replace(invoice,'const pbNativeOverview=w==="overview",Ot=pbNativeOverview?null:await Me(ke);')
  .replace(parallel,'Me(`/api/lab/finance/summary?${At.toString()}${pbNativeOverview?"&pbNativeOverview="+(pb1572FinanceFirstLoad.current?"initial":"live"):""}`),extraPath?Me(extraPath):Promise.resolve(null)')
  .replace('o(Ot.invoices||[]),f(Et.summary||null),C(Et.customers||[]);','if(Ot){o(Ot.invoices||[]);pbNativeFinanceInvoicesLoaded.current=true;}f(Et.summary||null),C(Et.customers||[]);')
  .replace('pb1569LoadedFinanceView=x.useRef(null);','pb1569LoadedFinanceView=x.useRef(null),pbNativeFinanceInvoicesLoaded=x.useRef(false);')
  .replace(viewGuard,'const pbNativeLastFinanceView=pb1569LoadedFinanceView.current;pb1569LoadedFinanceView.current=w;\n   if(w==="overview"||w==="invoices"||pbNativeLastFinanceView==="overview"){if(w!=="overview"&&!pbNativeFinanceInvoicesLoaded.current)g(!0);void ce().catch(()=>{});return;}\n   const endpoint=');
 return source.slice(0,start)+body+source.slice(end);
}

function upgradeFinanceLive(source){
 source=require('./download-transition-patch.cjs').patchDownloadTransition(source);
 source=require('./document-ui-patch.cjs').patchDocumentUI(source);
 source=patchNativeFinanceOverview(source);
 const compact='const V=t=>{if(typeof t==="string"&&/^(?:OFF-|PB-)/.test(t))return t.replace(/^OFF-[A-F0-9]{32}-(?:INV|ORD|EXP|PAY|COR)-0*([1-9]\\d*|0)$/,"OFF-$1").replace(/^PB-[A-F0-9]{8}-(?:INV|ORD|EXP|PAY|COR|ADJ)-0*([1-9]\\d*|0)$/,"L-$1");return Number(t||0).toLocaleString("fa-IR")}';
 for(const before of ['const V=t=>Number(t||0).toLocaleString("fa-IR")','const V=t=>typeof t==="string"&&/^(?:PB-|OFF-)/.test(t)?t:Number(t||0).toLocaleString("fa-IR")','const V=t=>typeof t==="string"&&/^(?:OFF-|PB-)/.test(t)?t:Number(t||0).toLocaleString("fa-IR")'])source=source.replaceAll(before,compact);
 if(!source.includes('/* PB1526 quiet finance */')){
  const load='pb1472Load=async()=>{var Je;g(!0);try{const Ot=await Me(ke);';
  if(source.includes(load)){source=source.replace(load,'/* PB1526 quiet finance */pb1526Loaded=x.useRef(false),pb1472Load=async()=>{var Je;if(!pb1526Loaded.current)g(!0);try{const Ot=await Me(ke);pb1526Loaded.current=true;');}
  else{const legacy='ce=async()=>{var Je;g(!0);try{const Ot=await Me(ke);';if(source.includes(legacy))source=source.replace(legacy,'/* PB1526 quiet finance */pb1526Loaded=x.useRef(false),ce=async()=>{var Je;if(!pb1526Loaded.current)g(!0);try{const Ot=await Me(ke);pb1526Loaded.current=true;');}
 }
 source=source.replace('o(Ot.invoices||[])',"o((Ot.invoices||[]).slice().sort((a,b)=>(Date.parse(b.issued_at)||0)-(Date.parse(a.issued_at)||0)||String(b.id).localeCompare(String(a.id))))");
 if(source.includes('/* PB1525 finance polling */'))return source.replace('setInterval(visible,5000)','setInterval(()=>{if(document.hasFocus())visible();},5000)');
 const start=source.indexOf('/* PB1468 finance live */'),end=start<0?-1:source.indexOf('},[t]);',start);if(start<0||end<0)return source;
 let effect=source.slice(start,end);
 const before="void refresh();const stream=t==='lab'?",after="/* PB1525 finance polling */const visible=()=>{if(!document.hidden)void refresh();};const timer=t==='lab'?setInterval(()=>{if(document.hasFocus())visible();},5000):null;document.addEventListener('visibilitychange',visible);void refresh();const stream=t==='lab'?";
 const clean="return()=>{closed=true;stream?.stop();window.removeEventListener('photobridge-finance-changed',refresh);";
 if(!effect.includes(before)||!effect.includes(clean))throw Error('finance_polling_incompatible');
 effect=effect.replace(before,after).replace(clean,"return()=>{closed=true;clearInterval(timer);document.removeEventListener('visibilitychange',visible);stream?.stop();window.removeEventListener('photobridge-finance-changed',refresh);");
 return source.slice(0,start)+effect+source.slice(end);
}
function browserEvents(labId,onEvent){
 if(typeof window==='undefined'||window.pbDesktopEvents||typeof fetch!=='function'||typeof AbortController!=='function')return null;
 return pb1468SubscribeLabEvents({getAccount:()=>labId||'lab',onEvent,request:(url,options)=>{const token=typeof Sr==='function'?Sr():'',context=typeof yg==='function'?yg():null;return fetch(url,{...options,credentials:'include',headers:{...options.headers,'x-photobridge-portal':'lab',...(token?{Authorization:'Bearer '+token}:{}),...(token&&context?.role==='lab'?{'x-photobridge-impersonation':'1','x-photobridge-impersonation-lab-id':String(labId||context.labId)}:{})}});}});
}
function patchFinanceLive(source){
 const fi=source.indexOf('/api/lab/finance/summary?');let begin=fi<0?-1:source.indexOf('x.useEffect(()=>{ce();if(!window.pbNativeStorage)return;',fi),end=-1;
 if(begin>=0)end=source.indexOf('},[t]);',begin)+'},[t]);'.length;else{begin=fi<0?-1:source.indexOf('x.useEffect(()=>{ce()},[t]);',fi);if(begin>=0)end=begin+'x.useEffect(()=>{ce()},[t]);'.length;}
 if(begin>=0&&end>begin){const effect=`/* PB1468 finance live */const pbFinanceRef=x.useRef(ce);pbFinanceRef.current=ce;x.useEffect(()=>{let closed=false,busy=false,rerun=false;const refresh=async(event)=>{if(closed||document.hidden)return;if(busy){if(event?.type)rerun=true;return;}busy=true;try{await pbFinanceRef.current();}catch{}finally{busy=false;if(rerun){rerun=false;void refresh();}}};void refresh();const stream=t==='lab'?pb1468BrowserEvents(null,()=>window.dispatchEvent(new CustomEvent('photobridge-finance-changed'))):null;window.addEventListener('photobridge-finance-changed',refresh);window.addEventListener('photobridge-lab-finance-changed',refresh);window.addEventListener('photobridge-lab-orders-changed',refresh);window.addEventListener('focus',refresh);return()=>{closed=true;stream?.stop();window.removeEventListener('photobridge-finance-changed',refresh);window.removeEventListener('photobridge-lab-finance-changed',refresh);window.removeEventListener('photobridge-lab-orders-changed',refresh);window.removeEventListener('focus',refresh);};},[t]);`;source=source.slice(0,begin)+effect+source.slice(end);}
 const preview='function Oc({role:t,invoice:a,onClose:s}){';if(source.includes(preview))source=source.replace(preview,`function Oc({role:t,invoice:pbOriginalInvoice,onClose:s}){const[pbLiveInvoice,pbSetLiveInvoice]=x.useState(pbOriginalInvoice);x.useEffect(()=>pbSetLiveInvoice(pbOriginalInvoice),[pbOriginalInvoice]);x.useEffect(()=>{if(t!=='lab')return;let closed=false,busy=false;const refresh=async()=>{if(closed||busy||document.hidden)return;busy=true;try{const data=await Me('/api/lab/invoices'),fresh=(data.invoices||[]).find(i=>i.id===pbOriginalInvoice.id);if(!closed&&fresh)pbSetLiveInvoice(fresh);}catch{}finally{busy=false;}};const stream=pb1468BrowserEvents(null,refresh);window.addEventListener('photobridge-finance-changed',refresh);window.addEventListener('photobridge-lab-orders-changed',refresh);return()=>{closed=true;stream?.stop();window.removeEventListener('photobridge-finance-changed',refresh);window.removeEventListener('photobridge-lab-orders-changed',refresh);};},[t,pbOriginalInvoice.id]);const a=pbLiveInvoice;`);
 return source;
}

module.exports={patchOrderLive};
