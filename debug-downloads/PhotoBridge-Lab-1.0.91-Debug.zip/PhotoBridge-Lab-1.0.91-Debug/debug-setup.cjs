'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const root=__dirname;process.chdir(root);
function run(command,args,extra={}){const r=spawnSync(command,args,{cwd:root,stdio:'inherit',...extra});if(r.error)throw r.error;if(r.status!==0)throw Error(command+' exited with '+r.status);}
function node(file,args=[]){run(process.execPath,[file,...args]);}
function npm(args){run('npm.cmd',args,{shell:true});}
async function verifyUI(){await require('./prepare-assets.cjs').buildBundledUi({offline:false,refresh:false,pinnedDirectory:path.join(root,'debug-ui'),pinFile:path.join(root,'debug-ui-pin.json')});node('verify-native-ui.cjs');}
async function main(){
 const mode=process.argv[2]||'--run';
 if(mode==='--verify-ui-only'){await verifyUI();return;}
 if(process.platform!=='win32'||process.arch!=='x64')throw Error('Use Windows x64.');
 if(Number(process.versions.node.split('.')[0])!==22)throw Error('Install Node.js 22 LTS x64 from https://nodejs.org/en/download');
 const stamp=crypto.createHash('sha256').update(fs.readFileSync('package-lock.json')).update(process.versions.node).digest('hex');
 let ready;try{ready=JSON.parse(fs.readFileSync('.debug-setup.json','utf8'));}catch{}
 if(ready?.stamp!==stamp||!fs.existsSync('node_modules/electron/dist/electron.exe')||!fs.existsSync('node_modules/better-sqlite3/build/Release/better_sqlite3.node')){
  npm(['ci','--ignore-scripts','--no-audit','--no-fund']);
  node('node_modules/electron/install.js');
  node('node_modules/electron-builder/cli.js',['install-app-deps']);
  fs.writeFileSync('.debug-setup.json',JSON.stringify({stamp}));
 }
 await verifyUI();
 const electron=path.join(root,'node_modules/electron/dist/electron.exe');
 if(mode==='--test'){
  const tests=fs.readdirSync('test').filter(x=>x.endsWith('.test.cjs')).map(x=>'test/'+x);
  run(electron,['--require','./runtime-compat-auto.cjs','--test',...tests],{env:{...process.env,ELECTRON_RUN_AS_NODE:'1'}});
 }else if(mode==='--build'){
  node('prepare-access-runtime.cjs');node('node_modules/electron-builder/cli.js',['--win','nsis','--x64','--publish','never','-c.win.forceCodeSigning=false','-c.win.signExecutable=false']);node('verify-installer.cjs');
  console.log('Installer: '+path.join(root,'release','PhotoBridge-Lab-Setup-1.0.91-x64.exe'));
 }else if(mode==='--run'){
  const env={...process.env,ELECTRON_ENABLE_LOGGING:'1'};delete env.ELECTRON_RUN_AS_NODE;
  run(electron,['debug-main.cjs'],{env});
 }else throw Error('Unknown debug mode: '+mode);
}
if(require.main===module)main().catch(e=>{console.error(e.stack||e.message);process.exitCode=1;});
