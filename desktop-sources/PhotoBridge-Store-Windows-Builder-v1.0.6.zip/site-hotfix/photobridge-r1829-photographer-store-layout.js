/* PhotoBridge: photographer equipment-store view ONLY. Never change lab workspaces. */
(()=>{
 'use strict';
 if(window.__PB_R1829_PHOTOGRAPHER_STORE__)return;
 window.__PB_R1829_PHOTOGRAPHER_STORE__=true;
 const root=()=>document.getElementById('storePhotographerWorkspace');
 const visible=el=>!!(el&&el.getClientRects().length&&getComputedStyle(el).display!=='none'&&getComputedStyle(el).visibility!=='hidden');
 const onlyStore=()=>location.pathname.startsWith('/photographer')&&visible(root());
 const oldStyles=new WeakMap();let queued=false;
 const labLabel=/^(?:تعرفه\s*لابراتوار|تعریف\s*لابراتوار|دعوت\s*همکار|موقعیت\s*عکاسی)$/;
 function labHeader(){
  // Do not touch native store actions, lab's own pages, or nonheader controls.
  document.querySelectorAll('header button,header a,.photographerHeaderNav button,.photographerHeaderNav a,.photographerSecondaryHeader button,.photographerSecondaryHeader a').forEach(el=>{
   if(root()?.contains(el)||el.closest('#photographerStoreRoleHeader'))return;
   const match=labLabel.test(String(el.textContent||'').replace(/\s+/g,' ').trim());
   if(!match)return;
   if(onlyStore()){
    if(!oldStyles.has(el))oldStyles.set(el,{value:el.style.getPropertyValue('display'),priority:el.style.getPropertyPriority('display')});
    el.dataset.pbR1829LabHeaderHidden='1';el.style.setProperty('display','none','important');
   }else if(el.dataset.pbR1829LabHeaderHidden==='1'){
    const old=oldStyles.get(el);if(old?.value)el.style.setProperty('display',old.value,old.priority);else el.style.removeProperty('display');
    delete el.dataset.pbR1829LabHeaderHidden;oldStyles.delete(el);
   }
  });
 }
 function selectedShop(){try{return typeof selectedShopRecord==='function'?selectedShopRecord():null}catch{return null}}
 function sales(){if(!onlyStore())return;
  const r=root(),nav=r.querySelector('#storeSectionNavV673'),panel=r.querySelector('#salesPanel');
  const shop=selectedShop();if(!nav||!panel||!shop)return;
  // Respect the store's actual configuration. Do not turn on sales for rental-only stores.
  if(shop.sale_enabled===false)return;
  let button=nav.querySelector('[data-store-panel="salesPanel"]');
  if(!button){
   button=document.createElement('button');button.type='button';button.dataset.storePanel='salesPanel';button.textContent='فروش تجهیزات';
   button.addEventListener('click',()=>{if(typeof openStoreSection==='function')openStoreSection('salesPanel')});
   const rental=nav.querySelector('[data-store-panel="equipmentPanel"]');rental?.insertAdjacentElement('afterend',button);if(!rental)nav.appendChild(button);
  }
  if(button.hidden||button.getAttribute('aria-hidden')==='true'){
   button.hidden=false;button.disabled=false;button.removeAttribute('aria-hidden');button.style.removeProperty('display');
  }
  if(panel.hidden||panel.getAttribute('aria-hidden')==='true'){
   panel.hidden=false;panel.removeAttribute('aria-hidden');panel.style.removeProperty('display');
  }
 }
 function redundantCategory(){if(!onlyStore())return;
  for(const button of root().querySelectorAll('button')){
   if(String(button.textContent||'').replace(/\s+/g,' ').trim()!=='دسته‌بندی')continue;
   if(button.closest('#equipmentPanel,#salesPanel,.pbR67FilterToolbar'))continue; // Keep real inventory filters.
   const row=button.parentElement;if(!row)continue;
   const cart=[...row.querySelectorAll('button')].find(b=>/سبد\s*خرید/.test(b.textContent||''));
   if(cart){button.hidden=true;button.style.setProperty('display','none','important');button.dataset.pbR1829RedundantCategory='1'}
  }
 }
 function sync(){queued=false;labHeader();if(onlyStore()){sales();redundantCategory()}}
 function schedule(){if(queued)return;queued=true;requestAnimationFrame(sync)}
 function init(){new MutationObserver(schedule).observe(document.getElementById('root')||document.body,{childList:true,subtree:true});document.addEventListener('click',e=>{if(e.target.closest?.('[data-store-panel],.photographerHeaderNav button'))setTimeout(schedule,50)},true);window.addEventListener('popstate',schedule);window.addEventListener('focus',schedule);schedule()}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
