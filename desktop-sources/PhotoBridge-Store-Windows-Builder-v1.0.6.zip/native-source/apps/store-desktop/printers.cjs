'use strict';
// Electron printer names are Windows-owned. Never send a print job to an unintended fallback.
function printablePrinters(printers){
 if(!Array.isArray(printers))return [];
 const byName=new Set();return printers.filter(x=>{
  const name=String(x?.name||'').trim();if(!name||byName.has(name))return false;byName.add(name);return true;
 }).map(x=>({name:String(x.name),displayName:String(x.displayName||x.name),isDefault:!!x.isDefault,status:Number.isFinite(x.status)?x.status:null}));
}
function selectPrinter(printers,selection){
 const list=printablePrinters(printers),name=String(selection||'');
 if(name){const found=list.find(p=>p.name===name);if(!found)throw Object.assign(new Error('selected_printer_unavailable'),{status:409});return found}
 const available=list.find(x=>x.isDefault)||list[0];if(!available)throw Object.assign(new Error('no_printer_installed'),{status:409});return available;
}
module.exports={printablePrinters,selectPrinter};
