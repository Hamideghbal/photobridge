(()=>{
 'use strict';
 // Native Windows controls only; website and Laboratory are not changed.
 if(!window.__PB_DESKTOP_APP__||window.__PB_STORE_NATIVE_FINANCE__)return;
 window.__PB_STORE_NATIVE_FINANCE__=true;
 const style=document.createElement('style');
 style.textContent=`
 .pbStoreNativeActions{display:flex;gap:9px;flex-wrap:wrap;align-items:center;padding:10px 0;direction:rtl}
 .pbStoreNativeActions button{cursor:pointer;border:1px solid #c8d6ef;border-radius:9px;background:#eef3ff;color:#244b93;font:600 12px/1.8 Vazirmatn,Tahoma,sans-serif;padding:7px 12px}
 .pbStoreNativeActions button:disabled{opacity:.5;cursor:wait}
 .pbStoreNativeActions .pbStoreBackupPath{width:100%;color:#475467;font:12px/1.8 Vazirmatn,Tahoma,sans-serif;overflow-wrap:anywhere}
 .pbStoreNativeActions .pbStoreBackupNote{width:100%;color:#667085;font:11px/1.8 Vazirmatn,Tahoma,sans-serif}
 .pbStoreNativeActions .pbStoreNativeError{color:#b42318}
 .pbStoreNativeShade{position:fixed;inset:0;background:#1720308e;z-index:2147483639;display:grid;place-items:center;padding:18px;direction:rtl;font:13px/1.8 Vazirmatn,Tahoma,sans-serif}
 .pbStoreNativeDialog{display:flex;flex-direction:column;gap:12px;width:min(640px,95vw);max-height:90vh;overflow:auto;background:white;color:#182230;border-radius:16px;padding:18px;box-shadow:0 24px 80px #0d1b3436}
 .pbStoreNativeHead,.pbStoreNativeControls{display:flex;gap:8px;justify-content:space-between;align-items:center;flex-wrap:wrap}
 .pbStoreNativeDialog h3{font-size:17px;margin:0}
 .pbStoreNativeDialog button,.pbStoreNativeDialog select{cursor:pointer;border:1px solid #d0dcf0;border-radius:8px;background:#f0f4fb;color:#234b89;padding:8px;font:inherit}
 .pbStoreNativeDialog select{min-width:240px;max-width:95%}
 .pbStoreNativeNote{font-size:12px;color:#667085;white-space:pre-wrap}
 /* The web portal hides the scrollbar intentionally. On native Windows show
    a visible horizontal bar ONLY when these first-tab filters overflow. */
 @media(min-width:851px){
  html body.rentalAppReady .rentalHeaderFilterHost #itemsCategoryFilters,
  html body.rentalAppReady .rentalHeaderFilterHost #saleItemsCategoryFilters,
  html body.rentalAppReady .rentalHeaderFilterHost #pb848BookingHeaderTabs,
  html body.rentalAppReady .rentalHeaderFilterHost .pb848ContextTabs,
  html body.rentalAppReady .rentalItemsListBox .categoryFilters,
  html body.rentalAppReady .rentalSalesListBox .categoryFilters{
   overflow-x:auto!important;overflow-y:hidden!important;scrollbar-width:thin!important;
   overscroll-behavior-x:contain;min-width:0;
  }
  html body.rentalAppReady .rentalHeaderFilterHost #itemsCategoryFilters::-webkit-scrollbar,
  html body.rentalAppReady .rentalHeaderFilterHost #saleItemsCategoryFilters::-webkit-scrollbar,
  html body.rentalAppReady .rentalHeaderFilterHost #pb848BookingHeaderTabs::-webkit-scrollbar,
  html body.rentalAppReady .rentalHeaderFilterHost .pb848ContextTabs::-webkit-scrollbar,
  html body.rentalAppReady .rentalItemsListBox .categoryFilters::-webkit-scrollbar,
  html body.rentalAppReady .rentalSalesListBox .categoryFilters::-webkit-scrollbar{
   display:block!important;height:8px!important;background:#f0f3f9!important;
  }
  html body.rentalAppReady .rentalHeaderFilterHost #itemsCategoryFilters::-webkit-scrollbar-thumb,
  html body.rentalAppReady .rentalHeaderFilterHost #saleItemsCategoryFilters::-webkit-scrollbar-thumb,
  html body.rentalAppReady .rentalHeaderFilterHost #pb848BookingHeaderTabs::-webkit-scrollbar-thumb,
  html body.rentalAppReady .rentalHeaderFilterHost .pb848ContextTabs::-webkit-scrollbar-thumb{
   background:#a1b6dc!important;border-radius:5px!important;
  }
 }
 `;
 document.head.append(style);
 const $=(selector,root=document)=>root.querySelector(selector);
 function el(tag,content,parent,klass){const x=document.createElement(tag);if(content!==undefined)x.textContent=content;if(klass)x.className=klass;parent.append(x);return x}
 function btn(parent,label,onClick){const x=el('button',label,parent);x.type='button';x.addEventListener('click',onClick);return x}
 async function call(url,options){const response=await fetch(url,{cache:'no-store',...(options||{})});const body=await response.json().catch(()=>({}));if(!response.ok)throw Error(body.message||body.error||'عملیات انجام نشد');return body}
 const post=url=>call(url,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
 let popup=null;
 function notice(root,text,error=false){root.textContent=text;root.classList.toggle('pbStoreNativeError',error)}
 async function printers(){
  popup?.remove();const shade=el('div',undefined,document.body,'pbStoreNativeShade');popup=shade;
  const card=el('section',undefined,shade,'pbStoreNativeDialog');card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');
  const head=el('div',undefined,card,'pbStoreNativeHead');el('h3','انتخاب پرینتر ویندوز',head);btn(head,'بستن',()=>shade.remove());
  const controls=el('div',undefined,card,'pbStoreNativeControls');const picker=el('select',undefined,controls);picker.setAttribute('aria-label','انتخاب پرینتر');
  const save=btn(controls,'ثبت پرینتر',async()=>{save.disabled=true;try{await call('/desktop/printers/select',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:picker.value})});notice(info,'پرینتر ذخیره شد؛ چاپ‌های بعدی با دستگاه انتخاب‌شده انجام می‌شوند.')}catch(e){notice(info,e.message,true)}finally{save.disabled=false}});
  const refresh=btn(controls,'تازه‌سازی فهرست',()=>void load());const info=el('p','',card,'pbStoreNativeNote');
  async function load(){refresh.disabled=true;try{const r=await call('/desktop/printers');picker.replaceChildren();const defaultOption=el('option','پیش‌فرض ویندوز',picker);defaultOption.value='';for(const p of r.printers||[]){const opt=el('option',p.displayName+(p.isDefault?' · پیش‌فرض':''),picker);opt.value=p.name}picker.value=r.selected||'';notice(info,!r.selectedAvailable?'پرینتر انتخاب‌شده پیدا نشد؛ یک پرینتر دیگر انتخاب کن.':'فهرست پرینترهای همین کامپیوتر بارگذاری شد.',!r.selectedAvailable)}catch(e){notice(info,e.message,true)}finally{refresh.disabled=false}}
  shade.addEventListener('click',e=>{if(e.target===shade)shade.remove()});await load();picker.focus();
 }
 function mount(){
  const settings=$('#settings');if(!settings)return;
  if(!$('#pbStoreNativePrinterSettings',settings)){
   const actions=el('div',undefined,settings,'pbStoreNativeActions');actions.id='pbStoreNativePrinterSettings';btn(actions,'انتخاب پرینتر ویندوز',()=>void printers());
  }
  if(!$('#pbStoreManualFinanceBackup',settings)){
   const actions=el('div',undefined,settings,'pbStoreNativeActions');actions.id='pbStoreManualFinanceBackup';
   const folderLine=el('div','محل بکاپ: هنوز انتخاب نشده',actions,'pbStoreBackupPath');
   const status=el('div','برای بکاپ مالی، ابتدا یک پوشه را انتخاب کن. فایل تاریخ‌دار و فایل بازکردن آن داخل همان پوشه قرار می‌گیرند.',actions,'pbStoreBackupNote');
   async function refresh(){try{const r=await call('/desktop/finance-backups');folderLine.textContent='محل بکاپ: '+(r.folder||'هنوز انتخاب نشده')}catch{folderLine.textContent='برای انتخاب پوشه، ابتدا وارد حساب فروشگاه شو'}}
   const select=btn(actions,'انتخاب پوشه بکاپ',async()=>{select.disabled=true;try{const r=await post('/desktop/finance-backups/select-folder');if(!r.canceled){await refresh();notice(status,'پوشه انتخاب شد. اکنون می‌توانی بکاپ بگیری.')}}catch(e){notice(status,e.message,true)}finally{select.disabled=false}});
   const capture=btn(actions,'بکاپ‌گیری امور مالی',async()=>{capture.disabled=true;try{const r=await post('/desktop/finance-backups');notice(status,'بکاپ ذخیره شد: '+r.backup.jsonFile+' · برای نمایش، فایل '+r.backup.viewerFile+' را از پوشه باز کن.');await refresh()}catch(e){notice(status,e.message,true)}finally{capture.disabled=false}});
   btn(actions,'باز کردن پوشه بکاپ',async()=>{try{await post('/desktop/finance-backups/open-folder')}catch(e){notice(status,e.message,true)}});
   void refresh();
  }
  if(!$('#pbStoreNativeUpdateSettings',settings)){
   const actions=el('div',undefined,settings,'pbStoreNativeActions');actions.id='pbStoreNativeUpdateSettings';
   const info=el('div','نسخه سایت خودکار بررسی می‌شود؛ برای تغییر موتور ویندوز باید نسخه رسمی جدید منتشر شده باشد.',actions,'pbStoreBackupNote');
   const site=btn(actions,'بررسی و اعمال تغییرات سایت',async()=>{site.disabled=true;try{const r=await post('/desktop/ui-update/check');notice(info,r.state==='ready_after_form_close'?'نسخه سایت دریافت شد. پس از بستن فرم‌ها دوباره دکمه را بزن.':r.ok?'نسخه سایت بررسی و اعمال شد.':'بررسی نسخه سایت کامل نشد.')}catch(e){notice(info,e.message,true)}finally{site.disabled=false}});
   const app=btn(actions,'بررسی آپدیت برنامه ویندوز',async()=>{app.disabled=true;try{const r=await post('/desktop/app-update/check');notice(info,r.ok?'وضعیت نسخه: '+r.state+(r.version?' · '+r.version:''):r.message||'آپدیت رسمی در دسترس نیست.',!r.ok)}catch(e){notice(info,e.message,true)}finally{app.disabled=false}});
   const install=btn(actions,'نصب آپدیت دانلودشده',async()=>{install.disabled=true;try{await post('/desktop/app-update/install');notice(info,'نصب آپدیت شروع شد. برنامه پس از بررسی بسته می‌شود.')}catch(e){notice(info,e.message,true)}finally{install.disabled=false}});
   void call('/desktop/app-update/status').then(r=>{if(r.state==='ready')info.textContent='آپدیت نسخه '+r.version+' دانلود شده و آماده نصب است.'}).catch(()=>{});
  }
 }
 // Only explicit commitment actions print. Changing printer never reprints old documents.
 const previousCommitment=window.pb916PrintCommitment;
 if(typeof previousCommitment==='function'&&typeof window.__PB_DESKTOP_PRINT__==='function'){
  window.pb916PrintCommitment=async function(bookingId){try{
   const result=await window.__PB_DESKTOP_PRINT__({bookingId:String(bookingId||'')});
   if(result?.ok){window.storeNotice?.('برگه تعهدنامه به صف چاپ '+(result.deviceName||'ویندوز')+' فرستاده شد.','چاپ');return}
   const error=String(result?.message||result?.error||'print_failed');
   if(['selected_printer_unavailable','no_printer_installed'].includes(error)){window.storeNotice?.('پرینتر انتخاب‌شده پیدا نشد؛ از تنظیمات فروشگاه انتخابش کن.','خطای پرینتر');return}
   window.storeNotice?.('چاپ انجام نشد: '+error,'چاپ');if(confirm('چاپ مستقیم ممکن نشد. پنجره چاپ باز شود؟'))return previousCommitment.call(this,bookingId);
  }catch(e){window.storeNotice?.('اتصال به پرینتر برقرار نشد.','خطای چاپ')}};
 }
 mount();new MutationObserver(()=>mount()).observe(document.body,{childList:true,subtree:true});
})();
