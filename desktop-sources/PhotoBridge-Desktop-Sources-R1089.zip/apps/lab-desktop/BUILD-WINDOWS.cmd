@echo off
setlocal
cd /d %~dp0
call npm ci
if errorlevel 1 exit /b 1
call npm run dist:unsigned
if errorlevel 1 exit /b 1
echo.
echo Installer is in release\
pause
