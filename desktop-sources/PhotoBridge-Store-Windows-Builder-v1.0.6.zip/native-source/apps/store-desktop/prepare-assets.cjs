const fs=require('node:fs'),path=require('node:path');const root=path.join(__dirname,'runtime');fs.rmSync(root,{recursive:true,force:true});fs.mkdirSync(root,{recursive:true});fs.cpSync(path.resolve(__dirname,'../../dist/web'),root,{recursive:true,filter:p=>!['desktop-ui','downloads'].includes(path.basename(p))});fs.copyFileSync(path.resolve(__dirname,'../../dist/api/equipment-rental-portal.html'),path.join(root,'equipment-rental-portal.html'));fs.copyFileSync(path.join(__dirname,'desktop-overlay.js'),path.join(root,'desktop-overlay.js'));
fs.copyFileSync(path.join(__dirname,'desktop-finance.js'),path.join(root,'desktop-finance.js'));
fs.copyFileSync(path.join(__dirname,'desktop-photographers.js'),path.join(root,'desktop-photographers.js'));
// Keep the standalone viewer template available in the packaged native app.
// It is copied to the user's selected backup directory by finance-backup.cjs.
// Keep the current source checkout's frame-order controls available offline.
const frameUi=path.join(__dirname,'frame-orders-ui.js');
if(fs.existsSync(frameUi))fs.copyFileSync(frameUi,path.join(root,'frame-orders-ui.js'));

fs.writeFileSync(path.join(__dirname,'release-config.json'),JSON.stringify({signed:!!(process.env.CSC_LINK||process.env.WIN_CSC_LINK)}));

const crypto=require('node:crypto');const manifest=crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'equipment-rental-portal.html'))).digest('hex');fs.writeFileSync(path.join(root,'bundled-version.txt'),manifest);
