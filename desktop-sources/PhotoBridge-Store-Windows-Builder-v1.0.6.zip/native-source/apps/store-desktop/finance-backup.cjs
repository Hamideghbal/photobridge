'use strict';
// Store-only, offline, read-only financial backup. No cloud or laboratory mutation.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const MAX_FILE_BYTES=25*1024*1024;
const MAX_LEGACY_SQLITE_BYTES=512*1024*1024;
const MAX_BACKUPS=30;
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const namePattern=/^finance-\d{8}-\d{6}-[a-f0-9]{12}\.json$/;
function fail(message,status=400){return Object.assign(new Error(message),{status})}
function currentShop(store){
 const id=store.get('shopId');
 if(!store.get('auth')||!uuid.test(String(id||'')))throw fail('login_required',401);
 return String(id);
}
function directory(root,shop){if(!uuid.test(shop))throw fail('invalid_shop_id');return path.join(root,'finance-backups',shop)}
function fingerprint(payload){return crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex')}
function validate(document,shop){
 if(!document||document.format!=='photobridge-store-finance-v1'||document.shopId!==shop||!document.payload||!document.checksum)throw fail('invalid_finance_backup');
 if(!Array.isArray(document.payload.invoices)||!Array.isArray(document.payload.receipts)||!Array.isArray(document.payload.ledger))throw fail('invalid_finance_backup');
 if(fingerprint(document.payload)!==document.checksum)throw fail('finance_backup_checksum_mismatch');
 return document;
}
function backupName(date=new Date()){
 const time=date.toISOString().replace(/[-:]/g,'').slice(0,15).replace('T','-');
 return 'finance-'+time+'-'+crypto.randomBytes(6).toString('hex')+'.json';
}
function collectFinance(store){
 const shopId=currentShop(store),snapshot=store.snapshot();
 if(!snapshot||snapshot.shopId!==shopId)throw fail('finance_snapshot_unavailable',409);
 const view=store.view(),accounts=store.accounting(),overview=store.overview();
 const entities=view.entities||{},meta=view.meta||{};
 const entries=Array.isArray(accounts.entries)?accounts.entries:[];
 const receiptEntries=entries.filter(row=>String(row.direction||'')==='credit'||/payment|receipt|discount/i.test(String(row.entry_type||'')));
 const sales=Array.isArray(entities.saleOrders)?entities.saleOrders:[];
 const invoices=[...(accounts.invoices||[]).map(x=>({...x,source:'rental'})),
   ...sales.filter(x=>x.invoice_number||x.invoice_id).map(x=>({...x,source:'sale'}))];
 const payload={
  shop:{id:shopId,name:String(overview?.shop?.name||meta?.shop?.name||'فروشگاه')},
  lastSync:store.get('lastSync')||null,
  unsynchronizedOperations:store.rows().filter(x=>x.state==='pending'||x.state==='conflict').length,
  summary:accounts.summary||null,
  balances:accounts.balances||[],
  people:overview?.photographers||[],
  invoices,receipts:receiptEntries,ledger:entries,
  // Preserve original records, even when current invoice screens use fewer fields.
  sourceSaleOrders:sales,
  sourceAccountingMarks:entities.accountingMarks||[]
 };
 return {shopId,payload};
}
function saveDocument(root,document,shop,limit=MAX_BACKUPS){
 validate(document,shop);
 const dir=directory(root,shop);fs.mkdirSync(dir,{recursive:true,mode:0o700});
 const name=backupName(),dest=path.join(dir,name),tmp=dest+'.tmp';
 const body=JSON.stringify(document);
 if(Buffer.byteLength(body)>MAX_FILE_BYTES)throw fail('finance_backup_too_large',413);
 try{fs.writeFileSync(tmp,body,{flag:'wx',mode:0o600});fs.renameSync(tmp,dest)}catch(e){try{fs.rmSync(tmp,{force:true})}catch{}throw e}
 const list=fs.readdirSync(dir).filter(x=>namePattern.test(x)).sort().reverse();
 for(const old of list.slice(limit))fs.unlinkSync(path.join(dir,old));
 return {id:name,capturedAt:document.capturedAt,shopId:shop,sizeBytes:Buffer.byteLength(body)};
}
function createFinanceBackup({store,root,date=new Date()}){
 const {shopId,payload}=collectFinance(store);
 const document={format:'photobridge-store-finance-v1',shopId,capturedAt:date.toISOString(),payload,checksum:fingerprint(payload)};
 return saveDocument(root,document,shopId);
}
function listFinanceBackups({store,root}){
 const shop=currentShop(store),dir=directory(root,shop);
 if(!fs.existsSync(dir))return [];
 return fs.readdirSync(dir).filter(x=>namePattern.test(x)).sort().reverse().map(id=>{
  const stat=fs.statSync(path.join(dir,id));return {id,sizeBytes:stat.size,createdAt:stat.birthtime.toISOString()}
 });
}
function readFinanceBackup({store,root,id}){
 const shop=currentShop(store);
 if(!namePattern.test(String(id||'')))throw fail('invalid_finance_backup_id');
 const file=path.join(directory(root,shop),id),stat=fs.statSync(file,{throwIfNoEntry:false});
 if(!stat?.isFile())throw fail('finance_backup_not_found',404);
 if(stat.size>MAX_FILE_BYTES)throw fail('finance_backup_too_large',413);
 let document;try{document=JSON.parse(fs.readFileSync(file,'utf8'))}catch{throw fail('finance_backup_damaged')}
 return validate(document,shop);
}
function legacySqliteFinance(file,shop){
 const {DatabaseSync}=require('node:sqlite');
 let database;
 try{
  database=new DatabaseSync(file,{readOnly:true});
  const row=database.prepare('SELECT payload,received_at FROM snapshots WHERE shop=?').get(shop);
  if(!row)throw fail('finance_backup_wrong_shop',409);
  const snapshot=JSON.parse(row.payload);
  if(snapshot.shopId!==shop)throw fail('finance_backup_wrong_shop',409);
  const e=snapshot.entities||{},meta=snapshot.meta||{},people=e.photographers||[],ledger=e.entries||[];
  const receipts=ledger.filter(x=>x.direction==='credit'||/payment|discount|receipt/i.test(String(x.entry_type||'')));
  const sales=e.saleOrders||[];
  const invoices=[...(e.invoices||[]).map(x=>({...x,source:'rental'})),...sales.filter(x=>x.invoice_number||x.invoice_id).map(x=>({...x,source:'sale'}))];
  const debitTotal=ledger.filter(x=>x.direction==='debit').reduce((a,x)=>a+Number(x.amount||0),0),creditTotal=ledger.filter(x=>x.direction==='credit').reduce((a,x)=>a+Number(x.amount||0),0);
  const balances=people.map(p=>({user_id:p.user_id,name:p.name,balance:ledger.filter(x=>x.photographer_id===p.user_id).reduce((a,x)=>a+(x.direction==='debit'?Number(x.amount||0):-Number(x.amount||0)),0)}));
  const payload={shop:{id:shop,name:e.shop?.[0]?.name||meta.shop?.name||'فروشگاه'},lastSync:row.received_at||null,unsynchronizedOperations:0,summary:{debitTotal,creditTotal,balance:debitTotal-creditTotal},balances,people,invoices,receipts,ledger,sourceSaleOrders:sales,sourceAccountingMarks:e.accountingMarks||[]};
  return {format:'photobridge-store-finance-v1',shopId:shop,capturedAt:new Date().toISOString(),payload,checksum:fingerprint(payload)};
 }catch(e){if(e.status)throw e;throw fail('legacy_finance_backup_unreadable',400)}finally{try{database?.close()}catch{}}
}
function importFinanceBackup({store,root,file}){
 const shop=currentShop(store),stat=fs.statSync(file);
 if(!stat.isFile()||stat.size>MAX_LEGACY_SQLITE_BYTES)throw fail('finance_backup_too_large',413);
 let document;
 if(/\.(?:sqlite|db)$/i.test(file))document=legacySqliteFinance(file,shop);
 else{
  if(stat.size>MAX_FILE_BYTES)throw fail('finance_backup_too_large',413);
  try{document=JSON.parse(fs.readFileSync(file,'utf8'))}catch{throw fail('invalid_finance_backup')}
 }
 return saveDocument(root,validate(document,shop),shop);
}

// Manual, explicitly selected folder. Files are kept until the shop owner removes
// them. A date-stamped HTML viewer can be opened directly by double-clicking it,
// without launching the PhotoBridge desktop app or contacting its server.
function createFolderFinanceBackup({store,folder,date=new Date(),viewerTemplate=path.join(__dirname,'backup-viewer.html')}){
 const {shopId,payload}=collectFinance(store);
 if(typeof folder!=='string'||!path.isAbsolute(folder))throw fail('backup_folder_not_selected');
 const stat=fs.statSync(folder,{throwIfNoEntry:false});
 if(!stat?.isDirectory())throw fail('backup_folder_not_available');
 const document={format:'photobridge-store-finance-v1',shopId,capturedAt:date.toISOString(),payload,checksum:fingerprint(payload)};
 validate(document,shopId);
 const name=backupName(date),base=name.slice(0,-5),jsonPath=path.join(folder,name),htmlName=base+'-view.html',htmlPath=path.join(folder,htmlName);
 const body=JSON.stringify(document);
 if(Buffer.byteLength(body)>MAX_FILE_BYTES)throw fail('finance_backup_too_large',413);
 const template=fs.readFileSync(viewerTemplate,'utf8');
 if(template.split('__PB_EMBEDDED_DOCUMENT__').length!==3)throw fail('backup_viewer_template_invalid');
 // Script-tag injection must not be possible even with arbitrary names/notes.
 const safe=body.replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
 const html=template.replace('<script id="pb-backup-embedded" type="application/json">__PB_EMBEDDED_DOCUMENT__</script>',
   '<script id="pb-backup-embedded" type="application/json">'+safe+'</script>');
 if(html===template)throw fail('backup_viewer_template_invalid');
 // Write JSON first. If HTML cannot be written, roll back the just-created JSON;
 // never leave a backup that appears successful but has no viewer.
 try{
  fs.writeFileSync(jsonPath,body,{flag:'wx',mode:0o600});
  try{fs.writeFileSync(htmlPath,html,{flag:'wx',mode:0o600})}
  catch(e){fs.rmSync(jsonPath,{force:true});throw e}
 }catch(e){throw e}
 return {id:name,shopId,capturedAt:document.capturedAt,folder,jsonFile:name,viewerFile:htmlName,sizeBytes:Buffer.byteLength(body)};
}

module.exports={createFinanceBackup,listFinanceBackups,readFinanceBackup,importFinanceBackup,createFolderFinanceBackup,collectFinance,validate,fingerprint};
