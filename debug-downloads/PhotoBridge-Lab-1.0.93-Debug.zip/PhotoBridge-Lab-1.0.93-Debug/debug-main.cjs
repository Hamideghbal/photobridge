'use strict';
const {app}=require('electron'),fs=require('node:fs'),path=require('node:path');
const base=path.join(__dirname,'debug-data'),logs=path.join(__dirname,'debug-logs');
fs.mkdirSync(base,{recursive:true});fs.mkdirSync(logs,{recursive:true});
app.setName('PhotoBridge Lab Debug');app.setPath('userData',base);
const logFile=path.join(logs,'requests-'+new Date().toISOString().replace(/[:.]/g,'-')+'.jsonl');
function record(event){fs.appendFileSync(logFile,JSON.stringify({at:new Date().toISOString(),...event})+'\n');}
record({event:'start',version:require('./package.json').version,dataDirectory:base});
app.on('browser-window-created',(_event,win)=>{
 win.webContents.once('did-finish-load',()=>{if(win.webContents.getURL().startsWith('http://127.0.0.1:'))win.webContents.openDevTools({mode:'detach'});});
});
app.whenReady().then(()=>{
 const {session}=require('electron');
 const filter={urls:['http://127.0.0.1/*']};
 const details=d=>({method:d.method,path:new URL(d.url).pathname,status:d.statusCode,error:d.error});
 session.defaultSession.webRequest.onCompleted(filter,d=>{if(d.statusCode>=400)record({event:'http-error',...details(d)});});
 session.defaultSession.webRequest.onErrorOccurred(filter,d=>record({event:'network-error',...details(d)}));
});
require('./main.cjs');
