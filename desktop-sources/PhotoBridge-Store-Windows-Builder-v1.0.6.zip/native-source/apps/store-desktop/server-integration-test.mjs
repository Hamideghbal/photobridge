import {PGlite} from '@electric-sql/pglite';
import {createStoreDesktopSync} from '../../dist/api/storeDesktopSync.js';
import fs from 'node:fs';import assert from 'node:assert/strict';import {randomUUID as id} from 'node:crypto';
const db=new PGlite(),shop=id(),user=id(),device=id(),item=id();
await db.exec(`CREATE TABLE equipment_rental_shops(id uuid PRIMARY KEY);CREATE TABLE equipment_rental_shop_memberships(shop_id uuid,user_id uuid,role text,active boolean);CREATE TABLE equipment_rental_items(id uuid PRIMARY KEY,shop_id uuid,category text,title text,brand text,model text,daily_price bigint,deposit_amount bigint,stock_total int,active boolean,description text,sku text,updated_at timestamptz DEFAULT now(),deleted_at timestamptz);CREATE TABLE equipment_rental_accounting_entries(id uuid PRIMARY KEY,shop_id uuid,photographer_id uuid,entry_type text,direction text,amount bigint,description text,entry_date date,created_by uuid);`);
for(const t of ['equipment_sale_items','equipment_rental_bookings','equipment_rental_invoices','equipment_rental_booking_shortages','equipment_sale_orders'])await db.exec(`CREATE TABLE ${t}(id uuid PRIMARY KEY,shop_id uuid)`);
await db.exec(fs.readFileSync(new URL('../../migrations/165_store_desktop_sync.sql',import.meta.url),'utf8'));
await db.query('INSERT INTO equipment_rental_shops VALUES($1)',[shop]);await db.query("INSERT INTO equipment_rental_shop_memberships VALUES($1,$2,'photographer',true)",[shop,user]);
const client={query:async(sql,values)=>{const r=await db.query(sql,values);return {...r,rowCount:r.affectedRows||r.rows.length}},release(){}};
const handler=createStoreDesktopSync({pool:{connect:async()=>client},shopFor:async a=>a.shop?{id:a.shop}:null,overview:async()=>({}),bodyJson:async r=>r.body,sendJson:(r,status,data)=>Object.assign(r,{status,data})});
async function send(operation,account=shop){const res={};await handler({method:'POST',body:operation},res,new URL('https://test/api/rental/desktop/operation'),{shop:account,userId:user});return res}
const op={id:id(),deviceId:device,entityId:item,entity:'items',action:'item.create',payload:{title:'دوربین Canon R5',daily_price:100,deposit_amount:200,stock_total:2,active:true},createdAt:new Date().toISOString()};
assert.equal((await send(op)).status,200);assert.equal((await send(op)).data.replayed,true);assert.equal((await db.query('SELECT count(*)::int n FROM equipment_rental_items')).rows[0].n,1);
assert.equal((await send({...op,payload:{...op.payload,daily_price:999}})).data.error,'operation_id_reused');
await db.query('UPDATE equipment_rental_items SET daily_price=120 WHERE id=$1',[item]);
const update={...op,id:id(),action:'item.update',payload:{daily_price:150},baseRevision:0};assert.equal((await send(update)).data.error,'record_changed_on_server');assert.equal((await db.query('SELECT daily_price FROM equipment_rental_items')).rows[0].daily_price,120);
assert.equal((await send({...update,id:id(),baseRevision:1})).status,200);
const entry={id:id(),deviceId:device,entityId:id(),entity:'entries',action:'entry.create',payload:{photographerId:user,kind:'payment',amount:500,entryDate:'2026-10-04'},createdAt:op.createdAt};assert.equal((await send(entry)).status,200);assert.equal((await send(entry)).data.replayed,true);assert.equal((await db.query('SELECT sum(amount)::int n FROM equipment_rental_accounting_entries')).rows[0].n,500);
const alien=id();await db.query('INSERT INTO equipment_rental_shops VALUES($1)',[alien]);assert.equal((await send({...update,id:id()},alien)).data.error,'record_not_found');
assert.equal((await send(op,null)).status,401);
// Download receipts and snapshot must stay scoped to the authenticated store.
await db.exec(`ALTER TABLE equipment_rental_shop_memberships ADD COLUMN settlement_mode text, ADD COLUMN permanent_discount_percent numeric;
CREATE TABLE users(id uuid PRIMARY KEY,name text,mobile text);
CREATE TABLE photographer_profiles(user_id uuid,studio_name text);
CREATE TABLE equipment_rental_booking_items(id uuid,booking_id uuid);
CREATE TABLE external_accounting_marks(owner_type text,owner_id uuid,document_type text,document_id uuid,recorded boolean,recorded_at timestamptz);`);
async function snapshot(account){const res={};await handler({method:'GET'},res,new URL('https://test/api/rental/desktop/snapshot?operations='+op.id+','+entry.id+',invalid'),{shop:account,userId:user});return res}
const downloaded=await snapshot(shop);assert.equal(downloaded.status,200);assert.equal(downloaded.data.receipts.length,2);assert.equal(downloaded.data.entities.items[0].daily_price,150);assert.equal(downloaded.data.entities.entries.length,1);
const other=await snapshot(alien);assert.equal(other.data.receipts.length,0);assert.equal(other.data.entities.items.length,0);assert.equal(other.data.entities.entries.length,0);
// Receipt failure must roll back the actual financial write in the same transaction.
await db.exec("CREATE FUNCTION reject_receipt() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'simulated_receipt_failure'; END $$;CREATE TRIGGER reject_receipt BEFORE INSERT ON equipment_store_desktop_operations FOR EACH ROW EXECUTE FUNCTION reject_receipt();");
await assert.rejects(send({...entry,id:id(),entityId:id()}),/simulated_receipt_failure/);assert.equal((await db.query('SELECT count(*)::int n FROM equipment_rental_accounting_entries')).rows[0].n,1);
console.log('PASS PostgreSQL: idempotency, modified replay rejected, web revision conflicts, resolution, single payment, account isolation, transaction rollback, snapshot receipts and account isolation');await db.close();
