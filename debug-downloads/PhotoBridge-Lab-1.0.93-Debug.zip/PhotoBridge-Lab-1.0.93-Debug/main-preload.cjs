'use strict';
// The native popup owns order sound in this desktop profile. Other browser
// profiles keep their own preference. Do not mute videos or unrelated media.
try{if(location.hostname==='127.0.0.1')localStorage.setItem('lablink_lab_new_order_sound','off')}catch{}

const {contextBridge,ipcRenderer}=require('electron');
if(location.protocol==='http:'&&location.hostname==='127.0.0.1'&&location.port==='43761')contextBridge.exposeInMainWorld('pbNativeStorage',{invoke:(action,payload)=>ipcRenderer.invoke('lab-native-storage',action,payload)});

if(location.protocol==='http:'&&location.hostname==='127.0.0.1'&&location.port==='43761')contextBridge.exposeInMainWorld('pbDesktopEvents',{onDownloadRetry:callback=>{if(typeof callback!=='function')return;const listener=(_event,value)=>callback(value);ipcRenderer.on('lab-download-retry',listener);return()=>ipcRenderer.removeListener('lab-download-retry',listener)},orderProgress:value=>ipcRenderer.invoke('lab-order-progress',value),focusForPricing:labId=>ipcRenderer.invoke('lab-pricing-focus',labId),onChange:callback=>{if(typeof callback!=='function')return;const listener=()=>callback();ipcRenderer.on('lab-document-change',listener);return()=>ipcRenderer.removeListener('lab-document-change',listener);}});
