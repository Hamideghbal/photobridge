'use strict';
const {app,BrowserWindow,Tray,Menu,Notification,net,safeStorage,shell,dialog}=require('electron');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{Store}=require('./store.cjs'),{Sync}=require('./sync.cjs'),{createHost}=require('./host.cjs');
const {backup}=require('node:sqlite');let win,tray,store,sync,server,quitting=false,origin,updateReady=false,uiChecking=false,reopen=null;
if(!app.requestSingleInstanceLock())app.quit();else{app.on('second-instance',()=>show());app.whenReady().then(start).catch(e=>{dialog.showErrorBox('PhotoBridge Store',String(e.stack||e));app.quit()})}
app.on('before-quit',()=>{quitting=true});app.on('window-all-closed',()=>{});
async function show(){if(win){if(!win.isVisible()&&reopen)await reopen();win.show();win.restore();win.focus()}}
async function start(){
 app.setAppUserModelId('ir.photobridge.store');const dir=app.getPath('userData');fs.mkdirSync(dir,{recursive:true});store=new Store(path.join(dir,'store.sqlite'));
 const bundled=app.isPackaged?path.join(process.resourcesPath,'runtime'):path.join(__dirname,'runtime');
 let authEpoch=0;let activeUiRoot=null;let base=store.get('serverUrl')||'https://photobridge.ir';
 async function request(p,options={}){
  if(!p.startsWith('/')||p.startsWith('//'))throw Error('invalid_remote_path');
  const {anonymous=false,...fetchOptions}=options,requestEpoch=authEpoch;let cookie='';const saved=anonymous?null:store.get('cookie');if(saved){if(!safeStorage.isEncryptionAvailable())throw Error('secure_storage_unavailable');cookie=safeStorage.decryptString(Buffer.from(saved,'base64'))}
  const response=await net.fetch(base+p,{...fetchOptions,headers:{'Content-Type':'application/json','Accept':'application/json','x-photobridge-portal':'rental',...(cookie?{Cookie:cookie}:{}),...fetchOptions.headers},redirect:'error',signal:fetchOptions.signal||AbortSignal.timeout(30000)});
  if(!anonymous){const values=response.headers.getSetCookie?.()||[];if(values.length&&requestEpoch===authEpoch){if(!safeStorage.isEncryptionAvailable())throw Error('secure_storage_unavailable');const pairs=Object.fromEntries(cookie.split(';').filter(Boolean).map(x=>x.trim().split(/=(.*)/s).slice(0,2)));for(const value of values){const pair=value.split(';')[0],i=pair.indexOf('=');pairs[pair.slice(0,i)]=pair.slice(i+1)}store.set('cookie',safeStorage.encryptString(Object.entries(pairs).map(([k,v])=>k+'='+v).join('; ')).toString('base64'))}}return response;
 }
 sync=new Sync({store,request,isOnline:()=>net.isOnline(),notify:b=>{const n=new Notification({title:'آفیش جدید · PhotoBridge',body:(b.customer_name||'عکاس')+' · '+String(b.rental_start).slice(0,10),silent:false,icon:path.join(__dirname,'assets','photobridge.png')});n.on('click',()=>{show();win.webContents.executeJavaScript("window.selectRentalTab?.('bookings',{reloadExtra:false});setTimeout(()=>window.pb843SetOfficeTab?.('pending'),100)").catch(()=>{})});n.show();shell.beep()}});
 const token=crypto.randomBytes(32).toString('hex');
 const printInFlight=new Map();
 const printCommitment=async bookingId=>{
  const shopId=store.get('shopId');if(!shopId||!store.get('auth'))throw Error('login_required');
  const booking=store.overview()?.bookings?.find(b=>String(b.id)===bookingId);
  if(!booking||!['picked_up'].includes(booking.status))throw Error('handover_not_confirmed_for_current_shop');
  if(booking.shop_id&&String(booking.shop_id)!==shopId)throw Error('print_shop_mismatch');
  const job=shopId+':'+bookingId+':'+String(booking.handover_serials_recorded_at||booking.updated_at||'');
  if(printInFlight.has(job))return printInFlight.get(job);
  const task=(async()=>{
   // Fetch the rendered document from the authenticated server, not from the local JSON API proxy.
   const response=await request('/api/rental/bookings/'+encodeURIComponent(bookingId)+'/commitment',{headers:{Accept:'text/html'}});
   if(!response.ok)throw Error('commitment_fetch_'+response.status);
   const html=await response.text();
   if(!/<!doctype|<html/i.test(html)||!html.includes('تعهدنامه'))throw Error('invalid_commitment_document');
   if(store.get('shopId')!==shopId||!store.get('auth'))throw Error('account_changed_before_print');
   const p=new BrowserWindow({show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
   try{
    // Data URL embeds the actual contract and registered serials. A localhost /api URL would
    // be parsed as JSON by host.cjs and could never render a printable document.
    await p.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
    await p.webContents.executeJavaScript('document.fonts?.ready.then(()=>true).catch(()=>true)',true).catch(()=>{});
    const printers=await p.webContents.getPrintersAsync();
    const selected=printers.find(x=>x.isDefault)||printers[0];
    if(!selected)throw Error('no_printer_installed');
    await new Promise((resolve,reject)=>p.webContents.print({silent:true,printBackground:true,deviceName:selected.name,pageSize:'A4'},(ok,reason)=>ok?resolve():reject(Error(reason||'printer_rejected_job'))));
    return {ok:true,queued:true,deviceName:selected.name};
   }finally{if(!p.isDestroyed())p.destroy()}
  })();
  printInFlight.set(job,task);
  try{return await task}finally{printInFlight.delete(job)}
 };
 server=createHost({store,sync,request,token,roots:()=>[activeUiRoot,bundled].filter(Boolean),printCommitment,onLogin:async()=>{
   await sync.pause();
   const authResponse=await request('/api/auth/me');if(!authResponse.ok)throw Error('login_failed');const auth=await authResponse.json();
   // Never attach previous shop's operation receipts to another account's initial snapshot.
   const response=await request('/api/rental/desktop/snapshot');if(!response.ok)throw Error('server_desktop_update_required');
   const snapshot=await response.json();
   const claimed=auth?.rentalShop?.id||auth?.shop?.id||auth?.shopId||null;
   if(!snapshot.shopId||typeof snapshot.shopId!=='string'||(claimed&&String(claimed)!==snapshot.shopId))throw Error('snapshot_account_mismatch');
   store.changeAccount(snapshot.shopId,auth);sync.acceptSnapshot(snapshot);
   sync.report=null;sync.online=true;sync.resume();await sync.run();
 },onLogout:async()=>{authEpoch++;return require('./session.cjs').logout(store,sync)}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 win=new BrowserWindow({width:1440,height:950,minWidth:1000,minHeight:650,backgroundColor:'#f5f7fb',title:'PhotoBridge Store',icon:path.join(__dirname,'assets','photobridge.png'),show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,spellcheck:false}});
 win.removeMenu();win.once('ready-to-show',()=>{if(!process.argv.includes('--background'))win.show()});win.on('close',e=>{if(!quitting){e.preventDefault();win.hide()}});
 win.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith(origin+'/')){e.preventDefault();if(url.startsWith('https://'))void shell.openExternal(url)}});
 win.webContents.setWindowOpenHandler(({url})=>url==='about:blank'?{action:'allow',overrideBrowserWindowOptions:{webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}}}:(url.startsWith('https://')&&void shell.openExternal(url),{action:'deny'}));
 win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 tray=new Tray(path.join(__dirname,'assets','photobridge.png'));tray.setToolTip('PhotoBridge Store · فعال در پس‌زمینه');tray.on('double-click',show);tray.setContextMenu(Menu.buildFromTemplate([{label:'باز کردن فوتوبریج',click:show},{label:'همگام‌سازی',click:()=>void sync.run()},{label:'پشتیبان‌گیری از اطلاعات',click:()=>void makeBackup()},{label:'تغییر آدرس سرور',click:()=>void configure()},{type:'separator'},{label:'خروج کامل (توقف اعلان‌ها)',click:()=>{quitting=true;app.quit()}}]));
 async function configure(){if(store.get('shopId')){dialog.showMessageBox(win,{message:'برای تغییر سرور ابتدا همگام‌سازی را کامل کن و از حساب خارج شو.'});return}const choice=await dialog.showOpenDialog(win,{title:'انتخاب فایل server.json شامل serverUrl',properties:['openFile'],filters:[{name:'JSON',extensions:['json']}]});if(choice.canceled)return;const config=JSON.parse(fs.readFileSync(choice.filePaths[0],'utf8')),u=new URL(config.serverUrl);if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/')throw Error('HTTPS server origin required');base=u.origin;store.set('serverUrl',base);store.set('cookie',null);win.reload()}
 async function makeBackup(){const folder=path.join(dir,'backups');fs.mkdirSync(folder,{recursive:true});await backup(store.db,path.join(folder,'store-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite'));const files=fs.readdirSync(folder).sort();for(const name of files.slice(0,-14))fs.unlinkSync(path.join(folder,name))}
 await applyUi(true);app.setLoginItemSettings({openAtLogin:true,args:['--background']});if(process.argv.includes('--background'))win.hide();
 if(!store.get('auth'))await sync.pause();await sync.run();setInterval(()=>{if(store.get('auth'))void sync.run()},30000).unref();void makeBackup().catch(e=>store.set('backupError',e.message));setInterval(()=>void makeBackup().catch(()=>{}),86400000).unref();
 // Native updates are installed only when the release is signed; UI revisions arrive over the authenticated HTTPS origin.
 try{const {autoUpdater}=require('electron-updater');autoUpdater.autoDownload=true;autoUpdater.autoInstallOnAppQuit=true;autoUpdater.on('error',e=>store.set('updateError',e.message));autoUpdater.on('update-downloaded',()=>{updateReady=true;new Notification({title:'PhotoBridge Store',body:'نسخه جدید آماده است؛ هنگام خروج کامل نصب می‌شود.'}).show()});if(app.isPackaged&&require('./release-config.json').signed){await autoUpdater.checkForUpdates().catch(()=>{});setInterval(()=>autoUpdater.checkForUpdates().catch(()=>{}),6*3600000).unref()}}catch(e){store.set('updateError',e.message)}
 async function applyUi(initial=false){
  const next=store.get('uiRoot'),exists=root=>{try{return Boolean(root&&fs.existsSync(path.join(root,'equipment-rental-portal.html')))}catch{return false}};
  if(!initial&&(!next||next===activeUiRoot))return true;
  const before=exists(activeUiRoot)?activeUiRoot:null,installedBuild=(()=>{try{return fs.readFileSync(path.join(bundled,'bundled-version.txt'),'utf8').trim()}catch{return null}})();const candidate=initial&&exists(bundled)?bundled:exists(next)&&(!installedBuild||installedBuild===store.get('bundledVersion'))?next:(before||bundled),failedBuild=store.get('uiBuild')||null;
  if(!initial&&candidate===activeUiRoot)return true;activeUiRoot=candidate;
  try{await win.loadURL(origin+'/start?token='+token);if(initial)store.set('bundledVersion',installedBuild);store.set('uiKnownGoodRoot',candidate);store.set('uiKnownGoodBuild',store.get('uiBuild')||null);store.set('uiAppliedAt',new Date().toISOString());store.set('uiFailedBuild',null);store.set('updateError',null);return true}
  catch(e){if(candidate!==bundled&&failedBuild)store.set('uiFailedBuild',failedBuild);store.set('updateError','ui_activation_failed:'+String(e.message||e));const previous=store.get('uiPreviousRoot'),known=store.get('uiKnownGoodRoot'),fallback=[before,previous,known,bundled].find(root=>root!==candidate&&exists(root));if(!fallback)throw e;activeUiRoot=fallback;store.set('uiRoot',fallback);let fallbackBuild=null;if(fallback===previous)fallbackBuild=store.get('uiPreviousBuild')||null;else if(fallback===known)fallbackBuild=store.get('uiKnownGoodBuild')||null;store.set('uiBuild',fallbackBuild);await win.loadURL(origin+'/start?token='+token);return false}
 }
 async function updateUi(startup=false){if(uiChecking)return false;uiChecking=true;try{const changed=await require('./ui-update.cjs').updateUi({store,request,bundled,directory:path.join(dir,'ui'),timeout:startup?90000:180000});if(changed&&!startup){if(!win.isVisible()){await applyUi(false);new Notification({title:'PhotoBridge Store',body:'نسخه جدید سایت دریافت و روی برنامه اعمال شد.'}).show()}else new Notification({title:'PhotoBridge Store',body:'نسخه جدید سایت دریافت شد؛ با بستن و باز کردن پنجره اعمال می‌شود.'}).show()}return changed}catch(e){store.set('updateError',e.message);return false}finally{uiChecking=false}}

 reopen=async()=>{await updateUi(true);await applyUi(false)};
 void updateUi();setInterval(()=>void updateUi(),10*60000).unref();
}
