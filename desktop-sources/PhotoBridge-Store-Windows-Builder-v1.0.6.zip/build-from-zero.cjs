#!/usr/bin/env node
'use strict';
/*
 * PhotoBridge Store: build from a clean Windows machine (Node 22).
 * Keeps original latest web/portal + desktop overlay from the owner's private repo.
 * Applies the editable native Store 1.0.4 printer/finance source on top.
 * Never touches laboratory files or deploys to Liara/GitHub.
 * This builds an UNSIGNED Windows TEST installer and does not use the update signing key.
 */
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const cp=require('node:child_process');
const root=__dirname;
const repo='https://github.com/Hamideghbal/photobridge.git';
const archive='https://github.com/Hamideghbal/photobridge/archive/refs/heads/aaa-liara-release.zip';
const workspace=path.join(root,'workspace');
const project=path.join(workspace,'photobridge');
const out=path.join(root,'OUTPUT-SETUP');
const nativeSrc=path.join(root,'native-source','apps','store-desktop');
const required=[
  'dist/web/index.html',
  'dist/api/equipment-rental-portal.html',
  'apps/store-desktop/desktop-overlay.js',
  'apps/store-desktop/frame-orders-ui.js'
];
const checkOnly=process.argv.includes('--prepare-only');
const zipArg=process.argv.find(a=>a.startsWith('--repo-zip='));
const repoZipArg=zipArg?zipArg.slice('--repo-zip='.length):null;
const exists=p=>fs.existsSync(p);
const print=s=>process.stdout.write(String(s)+'\n');
function fail(message){throw new Error(message)}
function command(program,args,cwd,env){
 print('> '+program+' '+args.join(' '));
 const result=cp.spawnSync(program,args,{cwd,env:env||process.env,stdio:'inherit',shell:process.platform==='win32'&&/\.cmd$/i.test(program),windowsHide:false,maxBuffer:1024*1024});
 if(result.error)throw result.error;
 if(result.status!==0)fail(`${program} returned exit code ${result.status??'unknown'}`);
}
function isUsable(p){return required.every(name=>exists(path.join(p,...name.split('/'))));}
function repoZipList(){
 const dirs=[root,path.join(os.homedir(),'Downloads'),process.env.USERPROFILE?path.join(process.env.USERPROFILE,'Downloads'):null].filter(Boolean);
 const found=[];
 for(const d of new Set(dirs)){
  try{for(const e of fs.readdirSync(d,{withFileTypes:true})){
   if(e.isFile()&&/^photobridge-aaa-liara-release(?:\s*\(\d+\))?\.zip$/i.test(e.name)){
    const p=path.join(d,e.name);found.push({p,mtime:fs.statSync(p).mtimeMs});
   }
  }}catch{}
 }
 if(repoZipArg){const p=path.resolve(repoZipArg);if(!exists(p))fail('Repository ZIP not found: '+p);return p;}
 if(process.env.PB_STORE_REPO_ZIP){const p=path.resolve(process.env.PB_STORE_REPO_ZIP);if(!exists(p))fail('Repository ZIP not found: '+p);return p;}
 return found.sort((a,b)=>b.mtime-a.mtime)[0]?.p;
}
function extractZip(zip){
 const dest=path.join(workspace,'extracted-github');
 const marker=path.join(workspace,'.github-zip-sha256');
 const hasher=crypto.createHash('sha256');
 // Stream the archive through a fixed-size buffer: private repository ZIPs can be very large.
 const file=fs.openSync(zip,'r');
 try{const buf=Buffer.alloc(1024*1024);let count;
   while((count=fs.readSync(file,buf,0,buf.length,null))>0)hasher.update(buf.subarray(0,count));
 }finally{fs.closeSync(file)}
 const hash=hasher.digest('hex');
 if(exists(marker)&&fs.readFileSync(marker,'utf8')===hash){
  const p=findRepoDir(dest);if(p){print('Using previously extracted GitHub source: '+p);return p;}
 }
 fs.rmSync(dest,{recursive:true,force:true});fs.mkdirSync(dest,{recursive:true});
 if(process.platform!=='win32'){
  // Used for the local source-preparation verification, not for Windows users.
  command('unzip',['-q','-o',zip,'-d',dest],root);
 }else{
  const env={...process.env,PB_REPO_ZIP:zip,PB_REPO_DEST:dest};
  command('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-Command',
    'Expand-Archive -LiteralPath $env:PB_REPO_ZIP -DestinationPath $env:PB_REPO_DEST -Force'],root,env);
 }
 const result=findRepoDir(dest);
 if(!result)fail('Repository ZIP does not contain the current PhotoBridge web and desktop source. Download the aaa-liara-release ZIP.');
 fs.writeFileSync(marker,hash);return result;
}
function findRepoDir(dir){
 if(isUsable(dir))return dir;
 if(!exists(dir))return null;
 for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  if(entry.isDirectory()&&isUsable(path.join(dir,entry.name)))return path.join(dir,entry.name);
 }
 return null;
}
function cloneGit(){
 const git=process.platform==='win32'?'git.exe':'git';
 const test=cp.spawnSync(git,['--version'],{encoding:'utf8',windowsHide:true});
 if(test.status!==0)return null;
 const target=path.join(workspace,'git-checkout');
 if(!exists(path.join(target,'.git'))){
  fs.rmSync(target,{recursive:true,force:true});
  try{
   // Fetch just files needed by the native Windows store. Browser authentication
   // is provided by Git Credential Manager when available on the user's Windows.
   command(git,['clone','--filter=blob:none','--depth','1','--sparse','--single-branch','--branch','aaa-liara-release',repo,target],root);
   command(git,['-C',target,'sparse-checkout','set','--no-cone','/dist/web/','/dist/api/equipment-rental-portal.html','/apps/store-desktop/desktop-overlay.js','/apps/store-desktop/frame-orders-ui.js'],root);
  }catch(e){print('GitHub clone failed: '+e.message);return null;}
 }else{
  try{command(git,['-C',target,'pull','--ff-only'],root)}catch(e){print('Using existing GitHub checkout; update failed: '+e.message)}
 }
 if(!isUsable(target))return null;
 return target;
}
function prepareProject(base){
 if(!isUsable(base))fail('Required web/portal/overlay files are missing in the repository.');
 // Work in an independent copy, never overwrite the user's clone or ZIP extraction.
 const tag=path.join(project,'.photobridge-store-prepared');
 const stamp=crypto.createHash('sha256').update(base+':'+fs.statSync(path.join(base,'dist','web','index.html')).mtimeMs).digest('hex');
 if(!exists(tag)||fs.readFileSync(tag,'utf8')!==stamp||!isUsable(project)){
  print('Preparing an isolated project copy with the latest PhotoBridge site assets...');
  fs.rmSync(project,{recursive:true,force:true});
  fs.mkdirSync(project,{recursive:true});
  for(const sub of ['dist/web','dist/api/equipment-rental-portal.html','apps/store-desktop/desktop-overlay.js','apps/store-desktop/frame-orders-ui.js']){
   const from=path.join(base,...sub.split('/')),to=path.join(project,...sub.split('/'));
   fs.mkdirSync(path.dirname(to),{recursive:true});
   fs.cpSync(from,to,{recursive:true});
  }
 }
 if(!exists(nativeSrc))fail('Bundled native Store source is missing. Re-extract the Builder ZIP.');
 fs.cpSync(nativeSrc,path.join(project,'apps','store-desktop'),{recursive:true,force:true});
 // Add isolated photographer equipment-store patches to the *build copy* only.
 const frontend=path.join(root,'site-hotfix');
 const siteAssets=['photobridge-r1829-photographer-store-layout.js','photobridge-r1829-photographer-store-layout.css'];
 for(const name of siteAssets)fs.copyFileSync(path.join(frontend,name),path.join(project,'dist','web',name));
 const htmlFile=path.join(project,'dist','web','index.html');let html=fs.readFileSync(htmlFile,'utf8');
 if(!html.includes('/photobridge-r1829-photographer-store-layout.js')){
  const injection='<link rel="stylesheet" href="/photobridge-r1829-photographer-store-layout.css?v=r1829"><script defer src="/photobridge-r1829-photographer-store-layout.js?v=r1829"></script>';
  html=html.replace('</body>',injection+'</body>');fs.writeFileSync(htmlFile,html);
 }

 if(!isUsable(project))fail('Cannot prepare the project: desktop-overlay or frame-order UI is missing.');
 fs.writeFileSync(tag,stamp);
 return path.join(project,'apps','store-desktop');
}
function buildWindows(appdir){
 const hasDependencies=exists(path.join(appdir,'node_modules','electron','package.json'))&&exists(path.join(appdir,'node_modules','electron-builder','package.json'));
 if(hasDependencies){print('STEP 1/3: Reusing previously installed Electron dependencies (no npm ci).')}
 else{
  print('STEP 1/3: Install Electron dependencies with npm ci...');
  command(process.platform==='win32'?'npm.cmd':'npm',['ci','--no-fund','--no-audit'],appdir);
 }
 print('\nSTEP 2/3: Run native Store tests...');
 command(process.platform==='win32'?'npm.cmd':'npm',['test'],appdir);
 print('\nSTEP 3/3: Package the UNSIGNED Windows test installer...');
 // The owner's previous build failed with ECONNRESET during GitHub Electron download.
 // Retry using an alternate Electron binary mirror before the original source.
 let built=false,lastError=null;
 for(const mirror of [null,'https://npmmirror.com/mirrors/electron/']){
  const env={...process.env,CSC_IDENTITY_AUTO_DISCOVERY:'false',CSC_LINK:'',WIN_CSC_LINK:'',
   ELECTRON_MIRROR:mirror||'',npm_config_electron_mirror:mirror||''};
  print('Electron download source: '+(mirror||'Official GitHub'));
  try{command(process.platform==='win32'?'npm.cmd':'npm',['run','dist:unsigned'],appdir,env);built=true;break}
  catch(error){lastError=error;print('Package attempt failed: '+error.message);if(!mirror)print('Retrying with alternate Electron download mirror...')}
 }
 if(!built)fail('Installer packaging failed from both download sources: '+(lastError?.message||'unknown'));
 const releaseDir=path.join(appdir,'release');
 const installers=fs.readdirSync(releaseDir,{withFileTypes:true}).filter(e=>e.isFile()&&/\.exe$/i.test(e.name))
   .map(e=>path.join(releaseDir,e.name)).sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs);
 if(!installers.length)fail('Builder exited but no .exe setup file was found in release.');
 fs.mkdirSync(out,{recursive:true});
 const result=path.join(out,path.basename(installers[0]));
 fs.copyFileSync(installers[0],result);
 const size=fs.statSync(result).size;
 if(size<10*1024*1024)fail('Suspiciously small installer; inspect build output.');
 const sha=crypto.createHash('sha256');
 const fd=fs.openSync(result,'r');try{const buf=Buffer.alloc(256*1024);let n;while((n=fs.readSync(fd,buf,0,buf.length,null))>0)sha.update(buf.subarray(0,n));}finally{fs.closeSync(fd)}
 fs.writeFileSync(path.join(out,'SHA256SUMS.txt'),sha.digest('hex')+'  '+path.basename(result)+'\r\n');
 print('\nSUCCESS: Unsigned test Setup created: '+result);
 print('IMPORTANT: Test on a real Windows PC before installing over an existing production app.');
}
function main(){
 print('PhotoBridge Store 1.0.6 | build from zero | live photographers + shopper layout');
 print('This does not publish the application or modify the laboratory app.');
 const major=Number(process.versions.node.split('.')[0]);
 if(major!==22)fail('Node.js 22 x64 is required. Detected: '+process.version+' ('+process.arch+').');
 if(process.platform==='win32'&&process.arch!=='x64')fail('64-bit Node.js is required.');
 fs.mkdirSync(workspace,{recursive:true});
 let base;
 if(process.env.PB_PROJECT_SOURCE_DIR){base=path.resolve(process.env.PB_PROJECT_SOURCE_DIR);print('Using test/source folder: '+base)}
 else {
  const zip=repoZipList();
  if(zip){print('Found PhotoBridge repository ZIP: '+zip);base=extractZip(zip)}
  if(!base){print('No PhotoBridge repository ZIP found. Trying authenticated GitHub checkout...');base=cloneGit()}
  if(!base){
   print('\nACTION REQUIRED: Download the aaa-liara-release ZIP while signed in to GitHub:');
   print(archive);
   print('Put the ZIP next to BUILD-STORE.cmd or leave it in Downloads, then run BUILD-STORE.cmd again.');
   print('You do not need Git if you use the GitHub ZIP.');
   process.exitCode=3;return;
  }
 }
 const appdir=prepareProject(base);
 print('\nSOURCE READY: '+appdir);
 print('Embedded site assets and the newest Store overlay remain in the project.');
 if(checkOnly){
  print('PREPARE-ONLY: validating native source and preparing runtime assets...');
  command(process.execPath,['--test',path.join(appdir,'test','finance-printers.test.cjs')],appdir);
  command(process.execPath,[path.join(appdir,'prepare-assets.cjs')],appdir);
  if(!exists(path.join(appdir,'runtime','desktop-overlay.js')))fail('Desktop overlay not included in bundled runtime');
  if(!exists(path.join(appdir,'runtime','desktop-finance.js')))fail('Finance backup UI not included in bundled runtime');
  if(!exists(path.join(appdir,'runtime','frame-orders-ui.js')))fail('Store frame-order UI not included in bundled runtime');
  print('PASS: runtime contains web, portal, desktop overlay, finance UI and frame UI.');
 }else{
  if(process.platform!=='win32')fail('Installer packaging is intended for Windows 10/11 x64.');
  buildWindows(appdir);
 }
}
try{main()}catch(error){
 process.exitCode=1;
 console.error('\nBUILD STOPPED: '+String(error&&error.message||error));
 console.error('Your existing Windows Store application and its SQLite data were not touched.');
 console.error('Save this error output for diagnosis; do not delete user data or run cleanup commands.');
}
