﻿نسخهٔ ۱.۰.۱۵۸
۱. ZIP را کامل استخراج کنید.
۲. کلید اصلی update-private.pem را داخل پوشهٔ publisher-key بگذارید.
۳. BUILD-WINDOWS.cmd را اجرا کنید.
فایل نصب و JSON به‌روزرسانی پس از ساخت در پوشهٔ release تولید می‌شوند.
