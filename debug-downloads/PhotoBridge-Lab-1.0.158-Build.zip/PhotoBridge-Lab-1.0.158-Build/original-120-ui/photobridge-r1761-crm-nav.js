/* R1767: one shared admin-controlled Customers tab for both Photographer and Lab.
   Enabled/disabled together. Fail closed while loading; never create duplicate docks. */
(()=>{
  'use strict';
  if(window.pb1761CrmNavigation)return;
  window.pb1761CrmNavigation=true;
  const media=matchMedia('(max-width:820px)');
  const path=()=>location.pathname;
  const lab=()=>/^\/lab(?:\/|$)/.test(path())&&!/^\/lab\/(?:login|signup|register)(?:\/|$)/.test(path())&&!!document.querySelector('#root .labRoleWorkspace .labSingleHeader');
  const photo=()=>(/^\/photographer(?:\/|$)/.test(path())&&!/^\/photographer\/(?:login|signup|register|invite)(?:\/|$)/.test(path())&&
    (!!document.querySelector('#root main.photographerMain')||document.body.classList.contains('pbAuthenticatedPhotographerPortal'))
  )||(path()==='/equipment-rental/book'&&document.body.classList.contains('rentalPhotographerMode')&&!!document.querySelector('#photographerStoreBottomNav'));
  const activePortal=()=>lab()?'lab':photo()?'photographer':null;
  let enabled=null,fetchedPortal=null,loading=false,epoch=0,pending=false;
  // A single initial reveal is coordinated with photographer feature tabs.
  function settleDock(){
    if(!media.matches||window.pbR1877CrmNavReady)return;
    window.pbR1877CrmNavReady=true;
    // Real browsers deliver the one-time signal; isolated Node tests have no Event target.
    if(typeof window.dispatchEvent==='function'&&typeof Event==='function')window.dispatchEvent(new Event('pb-r1877-crm-ready'));
  }

  function make(portal,desktop,pane){
    const b=document.createElement('button');
    b.type='button';
    b.className=desktop?'pb1761CrmDesktopTab':'pb1761CrmMobileTab';
    b.dataset.pb1761Crm=portal;
    b.dataset.pbCrmPane=pane;
    const calendar=pane==='calendar';
    const title=calendar?'تقویم':'مشتریان';
    b.setAttribute('aria-label',title);
    if(desktop){
      // Match the existing lab header tab styling, without claiming a native tab source.
      b.dataset.source='.pb1761CrmNotANativeTab';
      const label=document.createElement('span');
      label.className='pb1149NavLabel';
      label.textContent='مشتریان';
      b.append(label);
    }else{
      const customersIcon='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3"/><path d="M3.5 19v-1.2A5.8 5.8 0 0 1 9.3 12h.4a5.8 5.8 0 0 1 5.8 5.8V19"/><path d="M16.8 5.5a3 3 0 0 1 0 5.7M18 13a5.3 5.3 0 0 1 2.5 4.5V19"/></svg>';
      const calendarIcon='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 10h18m-14 5h3m4 0h3"/></svg>';
      b.innerHTML=(calendar?calendarIcon:customersIcon)+'<em>'+title+'</em>';
    }
    b.addEventListener('click',()=>{
      if(window.pbCrmOpen){window.pbCrmOpen(portal,true,pane);return;}
      const query=new URLSearchParams({portal,crmRev:'r1867-crm-delivery'});
      if(calendar)query.set('view','calendar');
      if(!desktop)query.set('pbCrmMobile','1');
      location.assign('/customer-crm.html?'+query);
    });
    return b;
  }

  function recount(grid){
    if(!grid)return;
    const count=[...grid.children].filter(el=>!el.hidden&&el.dataset.pb1099Hidden!=='1'&&getComputedStyle(el).display!=='none').length;
    if(count&&grid.style.getPropertyValue('--pb1099-tabs')!==String(count))grid.style.setProperty('--pb1099-tabs',String(count));
  }
  function removeButton(button){
    const parent=button.parentElement;
    button.remove();
    recount(parent);
  }
  function clearButtons(){
    document.querySelectorAll('button[data-pb1761-crm]').forEach(removeButton);
  }
  async function loadVisibility(portal){
    if(!portal||loading)return;
    loading=true;
    const requestEpoch=epoch;
    try{
      let token='';try{token=sessionStorage.getItem('lablink_test_session')||''}catch{}
      const response=await fetch('/api/photographer/navigation-tabs',{
        credentials:'include',cache:'no-store',
        headers:{'x-photobridge-portal':portal,...(token?{authorization:'Bearer '+token}:{})}
      });
      if(!response.ok)throw Error('tab-settings-unavailable');
      const data=await response.json();
      if(requestEpoch!==epoch)return;
      enabled=data?.tabs?.customers===true;
      fetchedPortal=portal;
    }catch{
      if(requestEpoch!==epoch)return;
      // Never display a disabled or unverified tab during a network/auth error.
      enabled=false;
      fetchedPortal=portal;
    }finally{
      loading=false;
      schedule();
    }
  }
  function refresh(){
    const portal=activePortal();
    if(portal&&fetchedPortal===portal)void loadVisibility(portal);
    else schedule();
  }
  function resetVisibility(){
    epoch++;
    fetchedPortal=null;
    enabled=null;
    window.pbR1877CrmNavReady=false;
    document.documentElement.classList.remove('pbR1877DockReady');
    document.documentElement.classList.add('pbR1877DockPending');
    clearButtons();
    schedule();
  }
  function visibleDock(selector){
    return [...document.querySelectorAll(selector)].filter(grid=>grid.getClientRects().length).at(-1)||null;
  }
  function targetFor(portal){
    if(media.matches){
      if(portal==='lab')return visibleDock('#root .labRoleWorkspace .labBottomAppNavGrid,body>.pb1448LabPhoneDock .labBottomAppNavGrid');
      return visibleDock('#root .photographerBottomAppNav:not(.labBottomAppNav):not([data-pb1318-stale]) .photographerBottomAppNavGrid');
    }
    if(portal==='lab')return document.querySelector('#root .labRoleWorkspace .pb1147LabNav');
    const home=document.querySelector('#root .photographerHomeModeNav');
    const header=document.querySelector('#root .photographerHeaderNav');
    if(home&&getComputedStyle(home).display!=='none')return home;
    if(header&&getComputedStyle(header).display!=='none')return header;
    return header||home;
  }
  function render(){
    pending=false;
    const portal=activePortal();
    if(!portal){clearButtons();return;}
    if(fetchedPortal!==portal){clearButtons();void loadVisibility(portal);return;}
    if(enabled!==true){clearButtons();settleDock();return;}
    const target=targetFor(portal),kind=media.matches?'pb1761CrmMobileTab':'pb1761CrmDesktopTab';
    // Remove stale or differently sized copies before inserting the current one.
    for(const button of document.querySelectorAll('button[data-pb1761-crm]')){
      if(button.parentElement!==target||button.dataset.pb1761Crm!==portal||!button.classList.contains(kind))removeButton(button);
    }
    if(!target)return;
    let mounted=false;
    for(const pane of media.matches?['customers','calendar']:['customers']){
      if(target.querySelector(':scope > button[data-pb-crm-pane="'+pane+'"]'))continue;
      const button=make(portal,!media.matches,pane);
      if(portal==='lab'&&!media.matches){
        const album=target.querySelector('button[data-source=".albumTopNav"]');
        if(album)album.after(button);else target.prepend(button);
      }else target.append(button);
      mounted=true;
    }
    recount(target);
    settleDock();
    if(mounted&&new URLSearchParams(location.search).get('pbCrmTab')==='1')window.pbCrmOpen?.(portal,false);
  }
  function schedule(){
    if(pending)return;
    pending=true;
    queueMicrotask(render);
  }
  function boot(){
    const root=document.getElementById('root');
    const observer=new MutationObserver(schedule);
    observer.observe(root||document.body,{childList:true,subtree:true});
    if(root)observer.observe(document.body,{childList:true});
    schedule();
    window.addEventListener('popstate',refresh);
    window.addEventListener('pageshow',refresh);
    /* PB1775 settings refresh */
    window.addEventListener('focus',refresh);
    window.addEventListener('pb1761-customer-settings-updated',refresh);
    window.addEventListener('storage',event=>{if(event.key==='pb1761CustomerVisibilityUpdated')refresh()});
    if(typeof setInterval==='function')setInterval(()=>{if(!document.hidden&&activePortal())refresh()},60000);
    window.addEventListener('photobridge-auth-session-changed',resetVisibility);
    window.addEventListener('resize',schedule,{passive:true});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
    if(media.addEventListener)media.addEventListener('change',schedule);
    else if(media.addListener)media.addListener(schedule);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
})();
