'use strict';
const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.woff2':'font/woff2'};
function createHost({store,sync,request,roots,token,onLogin,onLogout,printCommitment,desktopUtilities}){
 const json=(res,code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
 const server=http.createServer(async(req,res)=>{try{
  const origin='http://127.0.0.1:'+server.address().port;if(req.headers.host!=='127.0.0.1:'+server.address().port)return json(res,403,{error:'invalid_host'});
  const url=new URL(req.url,origin);
  if(url.pathname==='/start'&&url.searchParams.get('token')===token){res.writeHead(302,{'Set-Cookie':'desktop='+token+'; HttpOnly; SameSite=Strict; Path=/','Location':'/equipment-rental/portal'});return res.end()}
  if(!String(req.headers.cookie||'').split(';').some(x=>x.trim()==='desktop='+token))return json(res,403,{error:'desktop_locked'});
  if(req.headers.origin&&req.headers.origin!==origin)return json(res,403,{error:'invalid_origin'});
  if(url.pathname==='/desktop/status'){const state=store.get('auth')?sync.status():{signedIn:false,online:false,syncing:false,conflicts:[]};return json(res,200,{...state,uiBuild:store.get('uiBuild')||null,uiLastCheckedAt:store.get('uiLastCheckedAt')||null,uiDownloadedAt:store.get('uiDownloadedAt')||null,uiAppliedAt:store.get('uiAppliedAt')||null,updateError:store.get('updateError')||null})}
  if(url.pathname==='/desktop/print-commitment'&&req.method==='POST'){if(!store.get('auth'))return json(res,401,{error:'login_required'});const chunks=[];for await(const c of req)chunks.push(c);const p=JSON.parse(Buffer.concat(chunks).toString()||'{}');if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(p.bookingId||'')))return json(res,400,{error:'invalid_booking'});try{return json(res,200,await printCommitment(String(p.bookingId)))}catch(e){return json(res,500,{error:'print_failed',message:e.message})}}
  if(url.pathname==='/desktop/sync'&&req.method==='POST'){if(!store.get('auth'))return json(res,401,{ok:false,error:'login_required'});const result=await sync.run();return json(res,result.ok?200:result.error==='login_required'?401:result.conflicts?409:503,result)}
  if(url.pathname==='/desktop/photographers/refresh'&&req.method==='POST'){
   if(!store.get('auth')||!store.get('shopId'))return json(res,401,{error:'login_required'});
   // Preserve the offline outbox; a live read must never reset local queues.
   // A sync error must not hide a successful authoritative GET.
   try{await sync.run()}catch{}
   try{
    const upstream=await request('/api/rental/overview',{headers:{'Cache-Control':'no-cache'}});
    if(!upstream.ok)return json(res,upstream.status,{error:'photographers_live_unavailable'});
    const live=await upstream.json(),shopId=String(store.get('shopId'));
    if(String(live?.shop?.id||'')!==shopId)return json(res,409,{error:'photographers_shop_mismatch'});
    if(!Array.isArray(live.photographers)||!Array.isArray(live.photographerInvites)||!Array.isArray(live.collaborationRequests))return json(res,502,{error:'photographers_invalid_live_response'});
    return json(res,200,{ok:true,fresh:true,shopId,photographers:live.photographers,photographerInvites:live.photographerInvites,collaborationRequests:live.collaborationRequests});
   }catch(e){return json(res,503,{error:'photographers_live_unavailable',message:'اتصال با سرور فروشگاه برقرار نشد.'})}
  }

  const chunks=[];let size=0;if(!['GET','HEAD'].includes(req.method))for await(const c of req){size+=c.length;if(size>30e6)throw Object.assign(Error('request_too_large'),{status:413});chunks.push(c)}const bytes=Buffer.concat(chunks);if(bytes.length&&String(req.headers['content-type']).startsWith('multipart/form-data')){if(!sync.online)return json(res,503,{error:'online_connection_required',message:'بارگذاری تصویر به اینترنت نیاز دارد.'});if(store.rows().length)return json(res,409,{error:'sync_pending'});const upstream=await request(req.url,{method:req.method,body:bytes,headers:{'Content-Type':req.headers['content-type']}});return json(res,upstream.status,await upstream.json())}const p=bytes.length?JSON.parse(bytes.toString()):{};
  if(desktopUtilities&&await desktopUtilities({req,res,url,p,json}))return;
  if(['/desktop/resolve','/desktop/discard'].includes(url.pathname)&&!store.get('auth'))return json(res,401,{error:'login_required'});
  if(url.pathname==='/desktop/resolve'&&req.method==='POST'){store.resolve(p.id);void sync.run();return json(res,200,{ok:true})}
  if(url.pathname==='/desktop/discard'&&req.method==='POST'){store.discard(p.id,p.cascade===true);return json(res,200,{ok:true})}
  if(url.pathname==='/api/auth/rental-login'&&req.method==='POST'){const previousCookie=store.get('cookie');try{const upstream=await request(url.pathname,{method:'POST',body:bytes.toString()}),data=await upstream.json();if(upstream.ok)await onLogin(data,upstream);else store.set('cookie',previousCookie);return json(res,upstream.status,data)}catch(e){store.set('cookie',previousCookie);throw e}}
  if(url.pathname==='/api/auth/logout'&&req.method==='POST'){const out=await onLogout();return json(res,200,{ok:true,...out,redirect:'/equipment-rental/portal'})}
  if(url.pathname==='/api/auth/me'&&store.get('auth'))return json(res,200,{...store.get('auth'),shopId:store.get('shopId')});
  if(url.pathname.startsWith('/api/')){
   if(!store.get('auth')||!store.get('shopId')||!store.snapshot())return json(res,401,{error:'rental_auth_required'});
   if(req.method==='GET'){
    if(url.pathname==='/api/rental/overview')return json(res,200,store.overview());
    if(url.pathname==='/api/rental/accounting')return json(res,200,store.accounting());
    if(url.pathname==='/api/rental/accounting/ledger'){const who=url.searchParams.get('photographerId'),from=url.searchParams.get('from'),to=url.searchParams.get('to'),all=store.accounting().entries.filter(x=>x.photographer_id===who).sort((a,b)=>String(a.entry_date).localeCompare(String(b.entry_date))),opening=store.summary(all.filter(x=>from&&String(x.entry_date).slice(0,10)<from)).balance,entries=all.filter(x=>(!from||String(x.entry_date).slice(0,10)>=from)&&(!to||String(x.entry_date).slice(0,10)<=to)).map(x=>({...store.overview().bookings.find(b=>b.id===x.booking_id),booking_total:store.overview().bookings.find(b=>b.id===x.booking_id)?.total_amount,...x}));return json(res,200,{entries,openingBalance:opening,summary:store.summary(entries,opening)})}
    if(url.pathname==='/api/rental/live'){const bookings=store.overview().bookings;return json(res,200,{version:store.get('lastSync'),pendingCount:bookings.filter(x=>x.status==='pending_approval').length,pending:[],activeCount:bookings.filter(x=>['reserved','picked_up'].includes(x.status)).length})}
    if(url.pathname==='/api/rental/catalog')return json(res,200,{catalog:store.overview().catalog});
   }
   if(url.pathname==='/api/rental/availability'&&req.method==='POST')return json(res,200,store.availability(p));
   if(!['GET','HEAD'].includes(req.method)){const out=store.mutate(req.method,url.pathname,p);if(out){void sync.run();return json(res,200,out)}}
   if(!sync.online){const cached=store.get('cache:'+req.url);return cached?json(res,200,cached):json(res,503,{error:'online_connection_required',message:'این بخش به ارتباط با سرور نیاز دارد.'})}
   if(!['GET','HEAD'].includes(req.method)&&store.rows().some(x=>['pending','conflict'].includes(x.state)))return json(res,409,{error:'sync_pending',message:'ابتدا همگام‌سازی عملیات محلی را کامل کن.'});
   const upstream=await request(req.url,{method:req.method,...(bytes.length?{body:bytes.toString()}:{})}),data=await upstream.json();if(upstream.ok&&req.method==='GET')store.set('cache:'+req.url,data);if(upstream.ok&&req.method!=='GET')void sync.run();return json(res,upstream.status,data);
  }
  let name=(url.pathname==='/'||url.pathname==='/rental'||url.pathname.startsWith('/rental/')||url.pathname.startsWith('/equipment-rental')||url.pathname==='/desktop/login')?'equipment-rental-portal.html':decodeURIComponent(url.pathname).replace(/^\/+/, '');if(name.includes('..')||name.includes('\\'))return json(res,403,{});
  for(const root of roots()){const file=path.resolve(root,name);if(!file.startsWith(path.resolve(root)+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile())continue;res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});if(name==='equipment-rental-portal.html'){let html=fs.readFileSync(file,'utf8');html=html.replace(/<head([^>]*)>/i,`<head$1><script>window.__PB_DESKTOP_FETCH__=window.fetch.bind(window);window.__PB_DESKTOP_APP__=true;window.__PB_DESKTOP_PRINT__=async job=>{const response=await fetch('/desktop/print-commitment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({bookingId:job.bookingId})});return response.json()};</script>`);const end=html.toLowerCase().lastIndexOf('</body>');const boot='<script src="/desktop-overlay.js"></script><script defer src="/desktop-finance.js"></script><script defer src="/desktop-photographers.js"></script>';html=end<0?html+boot:html.slice(0,end)+boot+html.slice(end);return res.end(html)}return fs.createReadStream(file).pipe(res)}
  json(res,404,{error:'not_found'});
 }catch(e){json(res,e.status||500,{error:e.message,message:e.message})}});return server;
}
module.exports={createHost};
