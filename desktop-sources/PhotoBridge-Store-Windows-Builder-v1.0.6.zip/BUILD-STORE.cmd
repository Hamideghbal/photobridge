@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title PhotoBridge Store - Full Windows Build
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js 22 x64 must be installed first.
  echo Download from https://nodejs.org/en/download
  pause
  exit /b 1
)
node "%~dp0build-from-zero.cjs"
set "BUILD_RESULT=%errorlevel%"
echo.
if not "%BUILD_RESULT%"=="0" (
 echo BUILD DID NOT COMPLETE. Read the explanation above.
) else (
 echo Finished. Open OUTPUT-SETUP to find the unsigned Windows EXE.
)
pause
exit /b %BUILD_RESULT%
