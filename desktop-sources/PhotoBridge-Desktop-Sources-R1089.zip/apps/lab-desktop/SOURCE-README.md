# PhotoBridge Lab for Windows (restored source)

Source reconstructed from `PhotoBridge_Lab_Desktop_R72_Source.zip` and the newer `PhotoBridge_R97_Patch_Desktop_Auto_Update.zip`.  Native Electron changes from R97 supersede matching R72 files; store, sync, assets and configuration originate from R72.  This is a buildable source tree, not a prebuilt installer.

Build from repository root with Node 22 / Windows x64:

```powershell
cd apps/lab-desktop
npm ci
npm test
npm run dist:unsigned
```

The `prepare-assets.cjs` script bundles the full `dist/web` tree present at build time into `runtime`. To bake the latest UI into the setup, use the latest PhotoBridge `main` before building.  A signed release requires an Authenticode certificate and validation on Windows.

Before publishing, test login, logout, offline queue and UI update with two lab accounts. Do not erase local databases to fix account-boundary issues.
