﻿param([ValidateSet('Run','Test','Build')][string]$Mode='Run')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
Set-Location -LiteralPath $PSScriptRoot
New-Item -ItemType Directory -Force -Path 'debug-logs' | Out-Null
$log=Join-Path $PSScriptRoot ('debug-logs\session-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
 Write-Host 'Install Node.js 22 LTS x64: https://nodejs.org/en/download'
 exit 1
}
# Windows PowerShell treats native stderr as ErrorRecord; keep it in the log.
$ErrorActionPreference='Continue'
& node debug-setup.cjs ('--'+$Mode.ToLowerInvariant()) 2>&1 | Tee-Object -FilePath $log
$code=$LASTEXITCODE
Write-Host ('Log saved to: '+$log)
exit $code
