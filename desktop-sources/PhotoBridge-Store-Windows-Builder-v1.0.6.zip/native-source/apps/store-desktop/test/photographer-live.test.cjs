'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const {createHost}=require('../host.cjs');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
async function open(options={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'pb-store-photographers-'));
 fs.writeFileSync(path.join(dir,'equipment-rental-portal.html'),'<html><head></head><body></body></html>');
 fs.writeFileSync(path.join(dir,'desktop-photographers.js'),'window.testPhotographers=true;');
 let syncCalls=0,fetchCalls=0;
 const shopId='store-1',store={get:k=>k==='auth'?{userId:'owner-1'}:k==='shopId'?shopId:null};
 const server=createHost({store,sync:{online:true,run:async()=>{syncCalls++;return {ok:true}}},request:async()=>{
  fetchCalls++;return{ok:true,json:async()=>({shop:{id:options.otherShop?'other-shop':shopId},photographers:[{user_id:'p1',name:'Fresh'}],photographerInvites:[{code:'abc'}],collaborationRequests:[{id:'c1',status:'pending'}]})};},roots:()=>[dir],token:'a-cookie',onLogin:async()=>{},onLogout:async()=>{}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 return{base,server,dir,counts:()=>({syncCalls,fetchCalls}),close:()=>{server.close();fs.rmSync(dir,{recursive:true,force:true})}};
}
test('authenticated Windows photographers endpoint refreshes server membership, invitations and collaboration requests',async()=>{
 const x=await open();try{
  const locked=await fetch(x.base+'/desktop/photographers/refresh',{method:'POST'});assert.equal(locked.status,403);
  const res=await fetch(x.base+'/desktop/photographers/refresh',{method:'POST',headers:{Cookie:'desktop=a-cookie'}});
  assert.equal(res.status,200);const d=await res.json();assert.equal(d.shopId,'store-1');assert.equal(d.photographers[0].name,'Fresh');assert.equal(d.photographerInvites[0].code,'abc');assert.equal(d.collaborationRequests[0].status,'pending');assert.deepEqual(x.counts(),{syncCalls:1,fetchCalls:1});
  const html=await fetch(x.base+'/equipment-rental/portal',{headers:{Cookie:'desktop=a-cookie'}});assert((await html.text()).includes('desktop-photographers.js'));
 }finally{x.close()}
});
test('Windows photographers rejects another shop response rather than showing another store data',async()=>{
 const x=await open({otherShop:true});try{
  const res=await fetch(x.base+'/desktop/photographers/refresh',{method:'POST',headers:{Cookie:'desktop=a-cookie'}});
  assert.equal(res.status,409);assert.equal((await res.json()).error,'photographers_shop_mismatch');
 }finally{x.close()}
});
