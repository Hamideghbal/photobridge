const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
test('lab source includes offline store, scoped login, and bundle script',()=>{
 for(const f of ['main.cjs','host.cjs','store.cjs','sync.cjs','session.cjs','prepare-assets.cjs','ui-update.cjs','package.json'])assert(fs.existsSync(require('node:path').join(__dirname,'..',f)),f);
 const main=fs.readFileSync(require('node:path').join(__dirname,'../main.cjs'),'utf8');
 assert(main.includes('primeCache'));
 assert(main.includes('lab_admin_required'));
});
