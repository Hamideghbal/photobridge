'use strict';
async function logout(store,sync){
 await sync.pause();
 const pending=store.rows().filter(x=>x.state==='pending'||x.state==='conflict').length;
 store.transaction(()=>{
  store.set('auth',null);store.set('cookie',null);store.set('shopId',null);
  store.set('lastSync',null);store.set('lastSyncReport',null);
  store.db.prepare("DELETE FROM settings WHERE key LIKE 'cache:%'").run();
 });
 sync.online=false;sync.revision++;sync.report=null;sync.lastError=null;
 return {pendingSaved:pending};
}
module.exports={logout};
