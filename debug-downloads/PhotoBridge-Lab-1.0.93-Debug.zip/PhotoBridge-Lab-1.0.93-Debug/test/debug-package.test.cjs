'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),vm=require('node:vm');
test('debug launcher separates user data and logs only unsuccessful request metadata',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'pb-debug-package-')),paths={},handlers={};let loaded=false;
 const app={setName(){},setPath:(key,value)=>paths[key]=value,on:(event,cb)=>handlers[event]=cb,whenReady:()=>Promise.resolve()};
 const callbacks={},session={defaultSession:{webRequest:{onCompleted:(_filter,cb)=>callbacks.completed=cb,onErrorOccurred:(_filter,cb)=>callbacks.failed=cb}}};
 try{
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../debug-main.cjs'),'utf8'),{__dirname:root,URL,require:name=>{
   if(name==='electron')return{app,session};if(name==='./package.json')return{version:'1.0.93'};
   if(name==='./main.cjs'){loaded=true;return{};}return require(name);
  }});
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(paths.userData,path.join(root,'debug-data'));assert(loaded);
  callbacks.completed({url:'http://127.0.0.1:1234/api/lab/orders?token=private-value',method:'GET',statusCode:200});
  callbacks.completed({url:'http://127.0.0.1:1234/api/lab/orders?token=private-value',method:'POST',statusCode:409,body:'private-body'});
  const file=fs.readdirSync(path.join(root,'debug-logs')).find(x=>x.endsWith('.jsonl'));
  const text=fs.readFileSync(path.join(root,'debug-logs',file),'utf8'),rows=text.trim().split('\n').map(x=>JSON.parse(x));
  assert.equal(rows.length,2);assert.equal(rows[1].status,409);assert.equal(rows[1].path,'/api/lab/orders');assert(!text.includes('private-value'));assert(!text.includes('private-body'));
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
