@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo PhotoBridge Store - Windows candidate build
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js 22 is required on this computer.
  pause
  exit /b 1
)
for /f "tokens=1 delims=." %%V in ('node -p "process.versions.node"') do set "NODE_MAJOR=%%V"
if not "%NODE_MAJOR%"=="22" (
  echo ERROR: Required Node.js 22, detected Node.js %NODE_MAJOR%.
  pause
  exit /b 1
)
if not exist "..\..\dist\web\index.html" (
  echo ERROR: Place this folder inside the latest photobridge repository (apps\store-desktop).
  echo It requires the latest dist\web and dist\api\equipment-rental-portal.html.
  pause
  exit /b 1
)
if not exist "node_modules\electron\dist\electron.exe" (
  echo Installing native Windows dependencies...
  call npm ci
  if errorlevel 1 ( echo npm ci FAILED & pause & exit /b 1 )
)
echo Running tests...
call npm test
if errorlevel 1 ( echo Tests FAILED. Installer was not built. & pause & exit /b 1 )
echo Building unsigned Windows test installer...
call npm run dist:unsigned
if errorlevel 1 ( echo Installer build FAILED. & pause & exit /b 1 )
echo.
echo Candidate installer is in apps\store-desktop\release\
echo This is an UNSIGNED TEST installer; verify it on Windows before production use.
pause
endlocal
