'use strict';
const crypto=require('node:crypto');
const required=['shop','items','saleItems','bookings','bookingItems','photographers','invoices','entries','shortages','saleOrders'];
class Sync {
 constructor({store,request,notify,isOnline=()=>true}){Object.assign(this,{store,request,notify,isOnline});this.running=false;this.online=false;this.lastError=null;this.flight=null;this.paused=false;this.phase='idle';this.report=null;this.revision=0;this.sent=0;this.changed=false;}
 snapshotPath(){const ids=this.store.rows().filter(x=>['pending','confirmed'].includes(x.state)).sort((a,b)=>Number(b.state==='pending')-Number(a.state==='pending')).slice(0,100).map(x=>x.id);return '/api/rental/desktop/snapshot'+(ids.length?'?operations='+encodeURIComponent(ids.join(',')):'')}
 async read(response,stage){if(!response.ok){let data={};try{data=await response.json()}catch{}const code=response.status===401||response.status===403?'login_required':response.status===404?'server_desktop_update_required':data.error||'server_error';throw Object.assign(Error(code),{status:response.status,stage,detail:data})}let data;try{data=await response.json()}catch{throw Object.assign(Error('invalid_server_response'),{stage})}return data}
 validate(snapshot){if(snapshot?.protocol!==1)throw Error('server_desktop_update_required');if(snapshot.shopId!==this.store.get('shopId'))throw Error('snapshot_account_mismatch');if(!required.every(k=>Array.isArray(snapshot.entities?.[k])))throw Error('invalid_server_response');}
 acceptSnapshot(snapshot,{uncertain=false}={}){this.validate(snapshot);if(uncertain&&!Array.isArray(snapshot.receipts))throw Error('server_desktop_update_required');for(const receipt of snapshot.receipts||[]){const row=this.store.rows().find(x=>x.id===receipt.operationId&&x.state==='pending');if(!row)continue;const hash=crypto.createHash('sha256').update(JSON.stringify(row.operation)).digest('hex');if(receipt.payloadHash!==hash)throw Error('operation_id_reused');this.store.confirm(row.id,receipt.result)}const before=this.store.snapshot();this.changed=JSON.stringify(before?.entities)!==JSON.stringify(snapshot.entities)||JSON.stringify(before?.meta)!==JSON.stringify(snapshot.meta);this.store.install(snapshot);if(this.changed)this.revision++;}
 run(){if(this.flight)return this.flight;if(this.paused||!this.store.get('shopId'))return Promise.resolve({ok:false,error:'login_required',pulled:false,sent:0});this.running=true;this.controller=new AbortController();this.flight=this.perform().finally(()=>{this.running=false;this.phase='idle';this.flight=null});return this.flight}
 async pause(){this.paused=true;this.controller?.abort();if(this.flight)await this.flight;}
 resume(){this.paused=false;}
 send(path,options={}){return this.request(path,{...options,signal:AbortSignal.any([this.controller.signal,AbortSignal.timeout(15000)])})}
 async perform(){let pushError=null,pullError=null,uncertain=false;this.sent=0;this.report=null;this.lastError=null;this.phase='upload';const startedAt=new Date().toISOString();
  try{for(const queued of this.store.rows()){const row=this.store.rows().find(x=>x.id===queued.id);if(!row||row.state!=='pending'){if(row?.state==='conflict')break;continue}
   let response;try{response=await this.send('/api/rental/desktop/operation',{method:'POST',body:JSON.stringify(row.operation)})}catch(e){uncertain=true;throw e}
   if(response.status===409||response.status===400||response.status===422){let detail;try{detail=await response.json()}catch{detail={error:'invalid_server_response'}}this.store.conflict(row.id,detail);break}
   let result;try{result=await this.read(response,'upload')}catch(e){uncertain=response.status>=500||response.ok;throw e}
   if(!result?.ok){uncertain=true;throw Error('invalid_server_response')}
   this.store.confirm(row.id,result);this.sent++;
  }}catch(e){pushError=e}
  // A blocked upload must not hide newly received web/mobile data. Receipts reconcile an acknowledgement lost after commit.
  this.phase='download';let pulled=false;
  try{const response=await this.send(this.snapshotPath()),snapshot=await this.read(response,'download');this.acceptSnapshot(snapshot,{uncertain});pulled=true;this.online=true;
   for(const b of snapshot.entities.bookings.filter(x=>x.status==='pending_approval')){if(this.store.db.prepare('SELECT id FROM alert_seen WHERE id=?').get(b.id))continue;try{this.notify?.(b)}catch{}this.store.db.prepare('INSERT OR IGNORE INTO alert_seen VALUES(?,?)').run(b.id,new Date().toISOString())}
  }catch(e){pullError=e;this.online=false}
  const state=this.store.status();if(pushError&&pulled&&!state.pending&&!state.conflicts.length)pushError=null;
  const failure=pullError||pushError;this.lastError=failure?(this.isOnline()===false?'internet_offline':failure.message):null;
  const ok=pulled&&!failure&&!state.pending&&!state.conflicts.length;
  this.report={ok,pulled,sent:this.sent,pending:state.pending,conflicts:state.conflicts.length,error:this.lastError,stage:pullError?'download':pushError?'upload':null,httpStatus:failure?.status||null,startedAt,finishedAt:new Date().toISOString()};this.store.set('lastSyncReport',this.report);return this.report;
 }
 status(){const local=this.store.status(),connected=this.isOnline()!==false;return{...local,online:this.online&&connected&&!this.paused,syncing:this.running,phase:this.phase,sent:this.sent,revision:this.revision,error:!connected?'internet_offline':this.lastError,report:this.report||this.store.get('lastSyncReport'),signedIn:!!this.store.get('auth')};}
}
module.exports={Sync};
