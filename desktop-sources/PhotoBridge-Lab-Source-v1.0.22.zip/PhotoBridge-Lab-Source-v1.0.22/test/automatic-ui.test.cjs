'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),http=require('node:http');
const {buildBundledUi}=require('../prepare-assets.cjs');
const {updateUi}=require('../ui-update.cjs');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function setup(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'photobridge-lab-auto-'));
 const directory=path.join(root,'runtime'),ui=path.join(root,'local-ui');
 const data={'index.html':Buffer.from('<!doctype html><h1>latest Lab UI</h1>'),'desktop-overlay.js':Buffer.from('window.PB=1;'),'assets/lab.css':Buffer.from('body{color:#123}')};
 const files=Object.entries(data).map(([name,b])=>({name,url:'/lab-desktop-ui/'+name,sha256:hash(b)}));
 const manifest={protocol:1,channel:'lab',files,build:hash(JSON.stringify(files))};
 const reqs=[];let corrupt=false,badManifest=false,downloadRequests=0;
 const server=http.createServer((req,res)=>{
  reqs.push(req.url);if(req.url==='/api/desktop-ui/lab-manifest')return res.writeHead(404).end('old endpoint');
  if(req.url==='/api/lab/desktop-ui-manifest')return res.writeHead(200,{'content-type':'application/json'}).end(JSON.stringify(badManifest?{...manifest,build:hash('bogus')}:manifest));
  const name=req.url.slice('/lab-desktop-ui/'.length);
  if(!req.url.startsWith('/lab-desktop-ui/')||!data[name])return res.writeHead(404).end();
  downloadRequests++;const bytes=corrupt?Buffer.from('corrupt'):data[name];return res.writeHead(200,{'content-length':bytes.length}).end(bytes);
 });
 return {root,directory,ui,manifest,data,reqs,server,listen:()=>new Promise(resolve=>server.listen(0,'127.0.0.1',()=>resolve('http://127.0.0.1:'+server.address().port))),get downloads(){return downloadRequests},set corrupt(v){corrupt=v},set badManifest(v){badManifest=v},close:()=>new Promise(resolve=>server.close(()=>{fs.rmSync(root,{recursive:true,force:true});resolve()}))};
}
function storeFixture(){const data=new Map();return {get:k=>data.get(k),set:(k,v)=>data.set(k,v),transaction:fn=>fn()}}
test('building an installer embeds the exact latest authenticated-by-hash website UI',async()=>{
 const f=setup(),origin=await f.listen();try{
  await buildBundledUi({origin,directory:f.directory,log:()=>{}});
  assert.equal(f.downloads,3);
  assert.equal(f.reqs[0],'/api/desktop-ui/lab-manifest');
  assert.equal(f.reqs[1],'/api/lab/desktop-ui-manifest');
  for(const [name,raw] of Object.entries(f.data))assert.deepEqual(fs.readFileSync(path.join(f.directory,name)),raw);
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.directory,'.pb-lab-bundle-manifest.json'),'utf8')).build,f.manifest.build);
 }finally{await f.close()}
});
test('first launch activates fully verified bundled website UI without downloading redundant assets',async()=>{
 const f=setup(),origin=await f.listen();try{
  await buildBundledUi({origin,directory:f.directory,log:()=>{}});
  const first=f.downloads,store=storeFixture();
  const request=async url=>{assert.match(url,/manifest/);return {ok:true,json:async()=>f.manifest}};
  const result=await updateUi({store,request,bundled:f.directory,directory:f.ui});
  assert.equal(result,true);assert.equal(store.get('uiRoot'),f.directory);
  assert.equal(store.get('uiBuild'),f.manifest.build);
  assert.equal(f.downloads,first);
  assert(!fs.existsSync(path.join(f.ui,f.manifest.build)),'install should use the embedded UI directly');
  assert.equal(await updateUi({store,request,bundled:f.directory,directory:f.ui}),false);
 }finally{await f.close()}
});
test('tampered asset fails installer build closed, leaving previous bundle intact',async()=>{
 const f=setup(),origin=await f.listen();try{
  fs.mkdirSync(f.directory);fs.writeFileSync(path.join(f.directory,'index.html'),'trusted old website');
  f.corrupt=true;
  await assert.rejects(buildBundledUi({origin,directory:f.directory,log:()=>{}}),/ui_asset_hash_mismatch/);
  assert.equal(fs.readFileSync(path.join(f.directory,'index.html'),'utf8'),'trusted old website');
  assert(!fs.existsSync(f.directory+'.staging-'+process.pid));
 }finally{await f.close()}
});
test('invalid manifest prevents release with no partial overwrite',async()=>{
 const f=setup(),origin=await f.listen();try{
  f.badManifest=true;
  await assert.rejects(buildBundledUi({origin,directory:f.directory,log:()=>{}}),/ui_manifest_hash_mismatch/);
  assert(!fs.existsSync(f.directory));
 }finally{await f.close()}
});
test('native UI auto update remains safety-conscious: before login, background, verified, no data deletion',()=>{
 const native=fs.readFileSync(path.join(__dirname,'../main.cjs'),'utf8');
 const updater=fs.readFileSync(path.join(__dirname,'../ui-update.cjs'),'utf8');
 const pkg=JSON.parse(fs.readFileSync(path.join(__dirname,'../package.json'),'utf8'));
 assert.match(native,/await updateUi\(true\);await applyUi\(true\)/,'startup refresh precedes login');
 assert.match(native,/setInterval\(\(\)=>void updateUi\(\),10\*60000\)/,'automatic 10-minute checks');
 assert.match(native,/win\.on\('hide'.*applyUi\(false\)/,'apply quietly when inactive');
 assert.match(native,/reopen=async\(\)=>\{await applyUi\(false\);void updateUi\(false\)\}/,'apply downloaded UI before reshowing');
 assert.match(native,/if\(!win\.isVisible\(\)\)\{await applyUi\(false\)/,'never silently reload an active workspace');
 assert.match(native,/buttons:\['بعداً','اعمال نسخهٔ جدید'\]/,'manual override maintained');
 assert.match(updater,/update_hash_mismatch/,'checksum guard maintained');
 assert.match(updater,/\.partial/,'download staging maintained');
 assert.match(native,/lab\.sqlite/,'existing offline database preserved');
 assert.equal(pkg.build.nsis.deleteAppDataOnUninstall,false);
 assert.equal(pkg.version,'1.0.22');
});
test('later server updates are automatically downloaded, verified and never overwrite the fallback bundle',async()=>{
 const f=setup(),origin=await f.listen();try{
  await buildBundledUi({origin,directory:f.directory,log:()=>{}});
  const oldIndex=fs.readFileSync(path.join(f.directory,'index.html'));
  const store=storeFixture(),calls=[];
  const request=async(url)=>{
   calls.push(url);
   if(url.includes('manifest'))return {ok:true,json:async()=>f.manifest};
   const name=url.slice('/lab-desktop-ui/'.length),bytes=f.data[name];
   return {ok:true,headers:{get:()=>String(bytes.length)},arrayBuffer:async()=>bytes};
  };
  assert.equal(await updateUi({store,request,bundled:f.directory,directory:f.ui}),true);
  f.data['index.html']=Buffer.from('<!doctype html><h1>server updated</h1>');
  f.manifest.files=f.manifest.files.map(x=>x.name==='index.html'?{...x,sha256:hash(f.data['index.html'])}:x);
  f.manifest.build=hash(JSON.stringify(f.manifest.files));
  assert.equal(await updateUi({store,request,bundled:f.directory,directory:f.ui}),true);
  assert.notEqual(store.get('uiRoot'),f.directory,'new UI should be stored separately');
  assert.deepEqual(fs.readFileSync(path.join(store.get('uiRoot'),'index.html')),f.data['index.html']);
  assert.deepEqual(fs.readFileSync(path.join(f.directory,'index.html')),oldIndex,'immutable packaged UI retained as fallback');
  assert(calls.includes('/lab-desktop-ui/index.html'));
 }finally{await f.close()}
});
test('a corrupt bundled file is never trusted, and a fresh verified copy is downloaded',async()=>{
 const f=setup(),origin=await f.listen();try{
  await buildBundledUi({origin,directory:f.directory,log:()=>{}});
  fs.writeFileSync(path.join(f.directory,'index.html'),'tampered');
  const store=storeFixture(),downloads=[];
  const request=async url=>url.includes('manifest')?
   {ok:true,json:async()=>f.manifest}:
   (downloads.push(url),{ok:true,headers:{get:()=>null},arrayBuffer:async()=>f.data[url.slice('/lab-desktop-ui/'.length)]});
  assert.equal(await updateUi({store,request,bundled:f.directory,directory:f.ui}),true);
  assert(downloads.includes('/lab-desktop-ui/index.html'));
  assert.deepEqual(fs.readFileSync(path.join(store.get('uiRoot'),'index.html')),f.data['index.html']);
 }finally{await f.close()}
});
test('incompatible website updates cannot replace the active UI when native storage guard rejects them',async()=>{
 const f=setup(),origin=await f.listen();try{await buildBundledUi({origin,directory:f.directory,log:()=>{}});const store=storeFixture();store.set('uiRoot','old-working-ui');store.set('uiBuild','old-working-build');const request=async url=>url.includes('manifest')?{ok:true,json:async()=>f.manifest}:{ok:true,headers:{get:()=>null},arrayBuffer:async()=>f.data[url.slice('/lab-desktop-ui/'.length)]};await assert.rejects(updateUi({store,request,bundled:f.directory,directory:f.ui,acceptRoot:()=>{throw Error('native_storage_ui_incompatible')}}),/native_storage_ui_incompatible/);assert.equal(store.get('uiRoot'),'old-working-ui');assert.equal(store.get('uiBuild'),'old-working-build');assert.match(store.get('updateError'),/native_storage_ui_incompatible/);}finally{await f.close()}
});
