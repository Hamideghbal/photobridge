'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs');
const main=fs.readFileSync(require('node:path').join(__dirname,'../main.cjs'),'utf8');
const host=fs.readFileSync(require('node:path').join(__dirname,'../host.cjs'),'utf8');
test('Windows printer bridge queues a true background print job for server rendered commitment',()=>{
 assert.match(main,/getPrintersAsync\(\)/);
 assert.match(main,/silent:true/);
 assert.match(main,/printBackground:true/);
 assert.match(main,/deviceName:selected\.name/);
 assert(main.includes("request('/api/rental/bookings/"));
 assert.match(host,/\/desktop\/print-commitment/);
 assert.match(host,/__PB_DESKTOP_PRINT__/);
 assert.match(main,/handover_not_confirmed_for_current_shop/);
 assert.doesNotMatch(main,/await p\.loadURL\(origin\+'\/api\/rental\/bookings/);
});
