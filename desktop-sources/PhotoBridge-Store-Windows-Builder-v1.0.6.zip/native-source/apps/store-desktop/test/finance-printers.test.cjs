'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {Store}=require('../store.cjs');
const finance=require('../finance-backup.cjs');
const printer=require('../printers.cjs');
function fixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'photobridge-store-finance-'));
 const store=new Store(path.join(root,'store.sqlite'));
 const shopId=randomUUID(),personId=randomUUID(),invoiceId=randomUUID(),bookingId=randomUUID();
 store.set('shopId',shopId);store.set('auth',{userId:randomUUID(),rentalShop:{id:shopId}});
 const snapshot={protocol:1,shopId,meta:{shop:{id:shopId,name:'فروشگاه دوربین'},catalog:{}},entities:{shop:[{id:shopId,name:'فروشگاه دوربین'}],items:[],saleItems:[],saleOrders:[{id:randomUUID(),invoice_number:'SALE-100',total_amount:700,created_at:'2026-11-13'}],bookings:[{id:bookingId,shop_id:shopId,status:'picked_up',photographer_id:personId,total_amount:1500,rental_start:'2026-11-12',rental_end:'2026-11-13'}],bookingItems:[],invoices:[{id:invoiceId,booking_id:bookingId,shop_id:shopId,invoice_number:'INV-100',total_amount:1500,issued_at:'2026-11-13'}],entries:[{id:randomUUID(),shop_id:shopId,photographer_id:personId,entry_type:'booking_charge',direction:'debit',amount:1500,entry_date:'2026-11-13'},{id:randomUUID(),shop_id:shopId,photographer_id:personId,entry_type:'payment',direction:'credit',amount:500,entry_date:'2026-11-13'},{id:randomUUID(),shop_id:shopId,photographer_id:personId,entry_type:'discount',direction:'credit',amount:50,entry_date:'2026-11-13'}],shortages:[],photographers:[{id:personId,user_id:personId,name:'عکاسی الف'}],accountingMarks:[]}};
 store.install(snapshot);
 return {root,store,shopId,snapshot,cleanup(){store.close();fs.rmSync(root,{recursive:true,force:true})}};
}
test('Windows printer list is live, deduplicated, and selected devices never silently fall back',()=>{
 const list=printer.printablePrinters([{name:'EPSON TM',displayName:'Epson Thermal'},{name:'HP Laser',isDefault:true},{name:'HP Laser',isDefault:true}]);
 assert.equal(list.length,2);
 assert.equal(printer.selectPrinter(list,null).name,'HP Laser');
 assert.equal(printer.selectPrinter(list,'EPSON TM').name,'EPSON TM');
 assert.throws(()=>printer.selectPrinter(list,'Disappeared USB Printer'),/selected_printer_unavailable/);
 assert.throws(()=>printer.selectPrinter([],null),/no_printer_installed/);
});
test('financial backup contains invoices, receipts including discount, ledger, sales and totals offline',()=>{
 const x=fixture();try{
  const created=finance.createFinanceBackup({store:x.store,root:x.root,date:new Date('2026-11-13T12:00:00.000Z')});
  const doc=finance.readFinanceBackup({store:x.store,root:x.root,id:created.id});
  assert.equal(doc.shopId,x.shopId);assert.equal(doc.payload.shop.name,'فروشگاه دوربین');
  assert.equal(doc.payload.invoices.length,2);
  assert.equal(doc.payload.receipts.length,2);
  assert.equal(doc.payload.ledger.length,3);
  assert.equal(doc.payload.summary.balance,950);
  assert.equal(doc.payload.invoices[0].invoice_number,'INV-100');
  assert.equal(finance.listFinanceBackups({store:x.store,root:x.root}).length,1);
  assert.equal(doc.payload.unsynchronizedOperations,0);
 }finally{x.cleanup()}
});
test('financial backup stays immutable, verifies checksum, never imports another shop and refuses traversal',()=>{
 const x=fixture(),other=fixture();try{
  const b=finance.createFinanceBackup({store:x.store,root:x.root});
  x.store.mutate('POST','/api/rental/accounting/entries',{photographerId:x.snapshot.entities.photographers[0].user_id,amount:75,kind:'payment'});
  const original=finance.readFinanceBackup({store:x.store,root:x.root,id:b.id});
  assert.equal(original.payload.receipts.length,2,'backup must be frozen');
  assert.equal(original.payload.ledger.length,3);
  assert.throws(()=>finance.readFinanceBackup({store:x.store,root:x.root,id:'../other-shop/finance.json'}),/invalid_finance_backup_id/);
  assert.equal(finance.listFinanceBackups({store:other.store,root:x.root}).length,0);
  const file=path.join(x.root,'finance-backups',x.shopId,b.id);
  assert.throws(()=>finance.importFinanceBackup({store:other.store,root:other.root,file}),/invalid_finance_backup/);
  const doc=JSON.parse(fs.readFileSync(file));doc.payload.invoices[0].total_amount=1;fs.writeFileSync(file,JSON.stringify(doc));
  assert.throws(()=>finance.readFinanceBackup({store:x.store,root:x.root,id:b.id}),/checksum_mismatch/);
 }finally{x.cleanup();other.cleanup()}
});
test('financial backup can be imported only into the matching shop and no ledger operation is created',()=>{
 const x=fixture();try{
  const b=finance.createFinanceBackup({store:x.store,root:x.root});
  const file=path.join(x.root,'finance-backups',x.shopId,b.id);
  const oldOps=x.store.rows().length,copy=finance.importFinanceBackup({store:x.store,root:x.root,file});
  assert.notEqual(copy.id,b.id);assert.equal(finance.listFinanceBackups({store:x.store,root:x.root}).length,2);
  assert.equal(x.store.rows().length,oldOps);
 }finally{x.cleanup()}
});
test('unauthed local user cannot read other accounting backups; no runtime lab files modified',()=>{
 const x=fixture();try{
  finance.createFinanceBackup({store:x.store,root:x.root});x.store.set('auth',null);
  assert.throws(()=>finance.listFinanceBackups({store:x.store,root:x.root}),/login_required/);
  assert.throws(()=>finance.createFinanceBackup({store:x.store,root:x.root}),/login_required/);
  const main=fs.readFileSync(path.join(__dirname,'../main.cjs'),'utf8');
  const host=fs.readFileSync(path.join(__dirname,'../host.cjs'),'utf8');
  const prep=fs.readFileSync(path.join(__dirname,'../prepare-assets.cjs'),'utf8');
  assert(main.includes("store.get('printerChoice:'+shopId)"));
  assert(main.includes('desktopUtilities'));
  assert(main.includes('/desktop/finance-backups'));
  assert(host.includes('desktopUtilities')); 
  assert(host.includes('desktop-finance.js'));
  assert(prep.includes('desktop-finance.js'));
  const ui=fs.readFileSync(path.join(__dirname,'../desktop-finance.js'),'utf8');
  assert(ui.includes('window.pb916PrintCommitment=async function'));
  assert(ui.includes('window.__PB_DESKTOP_PRINT__')); 
 }finally{x.cleanup()}
});

test('local desktop host serves native controls only with its loopback cookie and injects UI script',async()=>{
 const {createHost}=require('../host.cjs');
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'pb-store-host-'));
 fs.writeFileSync(path.join(root,'equipment-rental-portal.html'),'<html><head></head><body><main id="app"></main></body></html>');
 fs.writeFileSync(path.join(root,'desktop-overlay.js'),'window.overlayLoaded=true;');
 fs.writeFileSync(path.join(root,'desktop-finance.js'),'window.financeLoaded=true;');
 const store={get:k=>k==='auth'?{}:k==='shopId'?randomUUID():null};
 const server=createHost({store,sync:{online:true},request:async()=>{},roots:()=>[root],token:'secret',onLogin:async()=>{},onLogout:async()=>{},printCommitment:async()=>({ok:true}),desktopUtilities:async({url,res,json})=>{if(url.pathname==='/desktop/printers'){json(res,200,{printers:[{name:'TEST'}]});return true}return false}});
 try{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base='http://127.0.0.1:'+server.address().port;
  const locked=await fetch(base+'/desktop/printers');assert.equal(locked.status,403);
  const start=await fetch(base+'/start?token=secret',{redirect:'manual'});assert.equal(start.status,302);
  const cookie=start.headers.get('set-cookie').split(';')[0];
  const wrongOrigin=await fetch(base+'/desktop/printers',{headers:{Cookie:cookie,Origin:'https://another-site.example'}});
  assert.equal(wrongOrigin.status,403);
  const printers=await fetch(base+'/desktop/printers',{headers:{Cookie:cookie}});assert.equal(printers.status,200);
  assert.equal((await printers.json()).printers[0].name,'TEST');
  const html=await fetch(base+'/equipment-rental/portal',{headers:{Cookie:cookie}});
  const source=await html.text();assert(source.includes('__PB_DESKTOP_APP__=true'));
  assert(source.includes('desktop-finance.js'));assert(source.includes('desktop-overlay.js'));
  const script=await fetch(base+'/desktop-finance.js',{headers:{Cookie:cookie}});assert((await script.text()).includes('financeLoaded'));
 }finally{server.close();fs.rmSync(root,{recursive:true,force:true})}
});

test('old per-device SQLite backups can be viewed as store finance for the same shop only',async()=>{
 const x=fixture(),y=fixture();try{
  const old=path.join(x.root,'store-old.sqlite');
  await require('node:sqlite').backup(x.store.db,old);
  const captured=finance.importFinanceBackup({store:x.store,root:x.root,file:old});
  const doc=finance.readFinanceBackup({store:x.store,root:x.root,id:captured.id});
  assert.equal(doc.payload.invoices.length,2);
  assert.equal(doc.payload.receipts.length,2);
  assert.equal(doc.payload.summary.balance,950);
  assert.throws(()=>finance.importFinanceBackup({store:y.store,root:y.root,file:old}),/wrong_shop/);
 }finally{x.cleanup();y.cleanup()}
});
