@echo off
start "" "https://github.com/Hamideghbal/photobridge/archive/refs/heads/aaa-liara-release.zip"
echo Sign into your GitHub account in the browser. Save the repo ZIP into Downloads.
echo Then run BUILD-STORE.cmd from the extracted builder folder.
pause
