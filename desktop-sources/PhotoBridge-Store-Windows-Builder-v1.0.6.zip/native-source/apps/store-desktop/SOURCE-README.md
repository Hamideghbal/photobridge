# Candidate update — Windows printer chooser + financial backup viewer (2026-11-13)

This source tree includes a proposed store-only native upgrade. The newer module `printers.cjs` enumerates Windows printers and stores per-shop selection. `finance-backup.cjs` adds per-shop offline financial backups and read-only viewing/import, and `desktop-finance.js` adds controls inside the Electron-hosted store page. See `README-PRINTER-FINANCE-FA.md` for details and cautions.

**Do not distribute an installer from this archived R1089 baseline without comparing it to the installed store version, testing on Windows, and signing/validating the result.** No live website/laboratory features are modified by this candidate source. The app package is a proposed `1.0.5` candidate only.

---

# PhotoBridge Store Windows R1089 source (candidate 1.0.3)

Restored from the last complete local Windows store source (R69 / v1.0.1) and the R97 Electron hot-update changes, with a native commitment-print bridge and account isolation fixes. This is NOT a signed Windows installer.

## Windows build

From the latest PhotoBridge repository root on Windows x64, using Node.js 22:

```powershell
cd apps/store-desktop
npm ci
npm test
npm run dist:unsigned
```

`prepare-assets.cjs` packages the **current checkout's** `dist/web` and `dist/api/equipment-rental-portal.html` into the installer so the first launch renders the bundled UI immediately. Future UI updates remain optional and happen later, without blocking startup.

### Functional changes

- Authenticated snapshot and new account identity are validated before switching active shop; each shop retains its own SQLite snapshot and offline outbox.
- Logout hides the previous shop, clears active credentials and shop identification, while leaving pending work in storage for its original owner.
- Native local print route takes a booking ID; it fetches the HTML commitment from the authenticated server, checks that its confirmed handover belongs to the current shop, selects the Windows default printer, and submits a **silent** A4 print job via Electron. Printer acceptance is not confirmation that paper physically printed.
- The storefront's `window.__PB_DESKTOP_PRINT__` bridge is exposed only inside the isolated localhost host; the remote website cannot call it directly.
- Existing Settings UI shows the automatic print option; that user preference remains per local installation.

### Release limits

Run and sign the NSIS package on Windows. No Windows installer was produced or validated in the ChatGPT environment. Do not replace the live installer until printing, switching between two accounts, sync queue recovery and first-launch UI parity have all been tested on an actual Windows PC.
