/* PhotoBridge Store Windows — live photographer membership, invitations and requests. */
(()=>{
 'use strict';
 if(window.__PB_DESKTOP_APP__!==true)return;
 if(window.__PB_STORE_PHOTOGRAPHERS_LIVE__)return;
 window.__PB_STORE_PHOTOGRAPHERS_LIVE__=true;
 let busy=false, last=0, generation=0;
 const tabSelected=()=>{
  const a=document.querySelector('#rentalDesktopPrimaryNav [data-rental-desktop-tab="photographers"].active,#rentalMobileBottomNav [data-rental-bottom-tab="photographers"].active,#tabs [data-tab="photographers"].active');
  const panel=document.getElementById('photographers');
  return !!a||!!(panel&&panel.classList.contains('active'));
 };
 const statusNode=()=>{let el=document.getElementById('pbStorePhotographerLiveNotice');if(el)return el;const host=document.getElementById('photographerList');if(!host?.parentElement)return null;el=document.createElement('p');el.id='pbStorePhotographerLiveNotice';el.setAttribute('role','status');el.style.cssText='font:600 12px/1.8 Vazirmatn,Tahoma,sans-serif;color:#667085;margin:4px 0 10px;direction:rtl';host.parentElement.insertBefore(el,host);return el};
 const explain=(message,color)=>{const el=statusNode();if(el){el.textContent=message;el.style.color=color||'#667085'}};
 async function refresh(force=false){
  if(!tabSelected()||busy||!navigator.onLine)return;
  if(!force&&Date.now()-last<30000)return;
  const epoch=++generation;busy=true;
  explain('در حال دریافت لیست به‌روز عکاس‌ها، دعوت‌نامه‌ها و درخواست‌های همکاری…');
  try{
   const res=await fetch('/desktop/photographers/refresh',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:'{}'});
   const payload=await res.json();
   if(!res.ok||!payload.ok||payload.fresh!==true)throw Error(payload.message||'دریافت اطلاعات به‌روز انجام نشد.');
   // The portal's original renderer remains the only authority for its actions.
   if(epoch!==generation||!tabSelected()||typeof data==='undefined'||typeof renderPhotographers!=='function')return;
   const shopId=String(data?.shop?.id||'');if(!shopId||shopId!==String(payload.shopId))throw Error('حساب فروشگاه تغییر کرده است.');
   const offline=(data.photographers||[]).filter(p=>p&&p._offline&&!payload.photographers.some(x=>String(x.user_id)===String(p.user_id)));
   data={...data,photographers:[...payload.photographers,...offline],photographerInvites:payload.photographerInvites,collaborationRequests:payload.collaborationRequests};
   renderPhotographers();last=Date.now();
   explain('اطلاعات همکاری از سرور به‌روز شد.'+(offline.length?' · '+offline.length+' عکاس آفلاین در انتظار همگام‌سازی است.':''),'#067647');
  }catch(e){if(epoch===generation)explain('اطلاعات محلی نمایش داده می‌شود؛ دریافت اطلاعات جدید انجام نشد. '+String(e.message||''),'#b54708')}
  finally{busy=false}
 }
 document.addEventListener('click',e=>{
  const el=e.target.closest?.('[data-rental-desktop-tab="photographers"],[data-rental-bottom-tab="photographers"],[data-tab="photographers"],[data-pb842-tab]');
  if(el)setTimeout(()=>refresh(true),100);
 },true);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)void refresh(false)});
 window.addEventListener('focus',()=>void refresh(false));
 window.addEventListener('online',()=>void refresh(true));
 document.addEventListener('click',e=>{if(e.target.closest?.('#sendRentalInviteSms,#photographerList button,#collaborationRequestList button,#rentalInviteHistory button'))setTimeout(()=>void refresh(true),1500)},true);
 setInterval(()=>{if(!document.hidden)void refresh(false)},45000);
 setTimeout(()=>void refresh(true),1100);
})();
