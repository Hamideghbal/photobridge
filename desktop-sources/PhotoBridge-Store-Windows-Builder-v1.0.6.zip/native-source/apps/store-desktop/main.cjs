'use strict';
const {app,BrowserWindow,Tray,Menu,Notification,net,safeStorage,shell,dialog}=require('electron');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{Store}=require('./store.cjs'),{Sync}=require('./sync.cjs'),{createHost}=require('./host.cjs');
const {backup}=require('node:sqlite');
const {printablePrinters,selectPrinter}=require('./printers.cjs');
const finance=require('./finance-backup.cjs');
let win,tray,store,sync,server,quitting=false,origin,updateReady=false,uiChecking=false,reopen=null;
if(!app.requestSingleInstanceLock())app.quit();else{app.on('second-instance',()=>show());app.whenReady().then(start).catch(e=>{dialog.showErrorBox('PhotoBridge Store',String(e.stack||e));app.quit()})}
app.on('before-quit',()=>{quitting=true});app.on('window-all-closed',()=>{});
async function show(){if(win){if(!win.isVisible()&&reopen)await reopen();win.show();win.restore();win.focus()}}
async function start(){
 app.setAppUserModelId('ir.photobridge.store');const dir=app.getPath('userData');fs.mkdirSync(dir,{recursive:true});store=new Store(path.join(dir,'store.sqlite'));
 const bundled=app.isPackaged?path.join(process.resourcesPath,'runtime'):path.join(__dirname,'runtime');
 let authEpoch=0;let activeUiRoot=null;let base=store.get('serverUrl')||'https://photobridge.ir';
 async function request(p,options={}){
  if(!p.startsWith('/')||p.startsWith('//'))throw Error('invalid_remote_path');
  const {anonymous=false,...fetchOptions}=options,requestEpoch=authEpoch;let cookie='';const saved=anonymous?null:store.get('cookie');if(saved){if(!safeStorage.isEncryptionAvailable())throw Error('secure_storage_unavailable');cookie=safeStorage.decryptString(Buffer.from(saved,'base64'))}
  const response=await net.fetch(base+p,{...fetchOptions,headers:{'Content-Type':'application/json','Accept':'application/json','x-photobridge-portal':'rental',...(cookie?{Cookie:cookie}:{}),...fetchOptions.headers},redirect:'error',signal:fetchOptions.signal||AbortSignal.timeout(30000)});
  if(!anonymous){const values=response.headers.getSetCookie?.()||[];if(values.length&&requestEpoch===authEpoch){if(!safeStorage.isEncryptionAvailable())throw Error('secure_storage_unavailable');const pairs=Object.fromEntries(cookie.split(';').filter(Boolean).map(x=>x.trim().split(/=(.*)/s).slice(0,2)));for(const value of values){const pair=value.split(';')[0],i=pair.indexOf('=');pairs[pair.slice(0,i)]=pair.slice(i+1)}store.set('cookie',safeStorage.encryptString(Object.entries(pairs).map(([k,v])=>k+'='+v).join('; ')).toString('base64'))}}return response;
 }
 sync=new Sync({store,request,isOnline:()=>net.isOnline(),notify:b=>{const n=new Notification({title:'آفیش جدید · PhotoBridge',body:(b.customer_name||'عکاس')+' · '+String(b.rental_start).slice(0,10),silent:false,icon:path.join(__dirname,'assets','photobridge.png')});n.on('click',()=>{show();win.webContents.executeJavaScript("window.selectRentalTab?.('bookings',{reloadExtra:false});setTimeout(()=>window.pb843SetOfficeTab?.('pending'),100)").catch(()=>{})});n.show();shell.beep()}});
 const token=crypto.randomBytes(32).toString('hex');
 const printInFlight=new Map();
 const printCommitment=async bookingId=>{
  const shopId=store.get('shopId');if(!shopId||!store.get('auth'))throw Error('login_required');
  const booking=store.overview()?.bookings?.find(b=>String(b.id)===bookingId);
  if(!booking||!['picked_up'].includes(booking.status))throw Error('handover_not_confirmed_for_current_shop');
  if(booking.shop_id&&String(booking.shop_id)!==shopId)throw Error('print_shop_mismatch');
  const job=shopId+':'+bookingId+':'+String(booking.handover_serials_recorded_at||booking.updated_at||'');
  if(printInFlight.has(job))return printInFlight.get(job);
  const task=(async()=>{
   // Fetch the rendered document from the authenticated server, not from the local JSON API proxy.
   const response=await request('/api/rental/bookings/'+encodeURIComponent(bookingId)+'/commitment',{headers:{Accept:'text/html'}});
   if(!response.ok)throw Error('commitment_fetch_'+response.status);
   const html=await response.text();
   if(!/<!doctype|<html/i.test(html)||!html.includes('تعهدنامه'))throw Error('invalid_commitment_document');
   if(store.get('shopId')!==shopId||!store.get('auth'))throw Error('account_changed_before_print');
   const p=new BrowserWindow({show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
   try{
    // Data URL embeds the actual contract and registered serials. A localhost /api URL would
    // be parsed as JSON by host.cjs and could never render a printable document.
    await p.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
    await p.webContents.executeJavaScript('document.fonts?.ready.then(()=>true).catch(()=>true)',true).catch(()=>{});
    const printers=await p.webContents.getPrintersAsync();
    const selected=selectPrinter(printers,store.get('printerChoice:'+shopId));
    await new Promise((resolve,reject)=>p.webContents.print({silent:true,printBackground:true,deviceName:selected.name,pageSize:'A4'},(ok,reason)=>ok?resolve():reject(Error(reason||'printer_rejected_job'))));
    return {ok:true,queued:true,deviceName:selected.name};
   }finally{if(!p.isDestroyed())p.destroy()}
  })();
  printInFlight.set(job,task);
  try{return await task}finally{printInFlight.delete(job)}
 };
 // The finance export is manual and goes only to a directory explicitly selected by
 // this shop. The local SQLite safety backup remains a separate existing feature.
 let autoUpdater=null;
 let appUpdateState='not_checked';
 let checkAppUpdate=async()=>({ok:false,state:'not_configured'});
 let applyUiNow=async()=>({ok:false,state:'not_ready'});
 const financeRoot=dir;
 const desktopUtilities=async({req,res,url,p,json})=>{
  const route=url.pathname;
  if(!route.startsWith('/desktop/printers')&&!route.startsWith('/desktop/finance-backups')&&!route.startsWith('/desktop/app-update')&&!route.startsWith('/desktop/ui-update'))return false;
  if(!store.get('auth')||!store.get('shopId')){json(res,401,{error:'login_required'});return true}
  const shopId=String(store.get('shopId'));
  if(route==='/desktop/printers'&&req.method==='GET'){
   const printers=printablePrinters(await win.webContents.getPrintersAsync());
   const chosen=store.get('printerChoice:'+shopId)||'';
   json(res,200,{printers,selected:chosen,selectedAvailable:!chosen||printers.some(x=>x.name===chosen),defaultPrinter:printers.find(x=>x.isDefault)?.name||printers[0]?.name||null});return true;
  }
  if(route==='/desktop/printers/select'&&req.method==='POST'){
   const choice=String(p?.name||'');
   if(choice.length>300){json(res,400,{error:'invalid_printer_name'});return true}
   if(choice)selectPrinter(await win.webContents.getPrintersAsync(),choice);
   store.set('printerChoice:'+shopId,choice||null);
   json(res,200,{ok:true,selected:choice||null});return true;
  }
  if(route==='/desktop/finance-backups'&&req.method==='GET'){
   json(res,200,{folder:store.get('financeBackupFolder:'+shopId)||null,shopId});return true;
  }
  if(route==='/desktop/finance-backups/select-folder'&&req.method==='POST'){
   const picked=await dialog.showOpenDialog(win,{title:'انتخاب پوشه ذخیره بکاپ مالی فروشگاه',properties:['openDirectory','createDirectory']});
   if(picked.canceled||!picked.filePaths?.[0]){json(res,200,{ok:false,canceled:true});return true}
   const folder=path.resolve(picked.filePaths[0]);if(!fs.statSync(folder).isDirectory()){json(res,400,{error:'backup_folder_not_available'});return true}
   store.set('financeBackupFolder:'+shopId,folder);
   json(res,200,{ok:true,folder});return true;
  }
  if(route==='/desktop/finance-backups'&&req.method==='POST'){
   const folder=store.get('financeBackupFolder:'+shopId);
   if(!folder){json(res,409,{error:'backup_folder_not_selected',message:'ابتدا پوشه بکاپ را انتخاب کنید.'});return true}
   const created=finance.createFolderFinanceBackup({store,folder});
   store.set('financeBackupError',null);
   json(res,201,{ok:true,backup:created});return true;
  }
  if(route==='/desktop/finance-backups/open-folder'&&req.method==='POST'){
   const folder=store.get('financeBackupFolder:'+shopId);
   if(!folder||!fs.statSync(folder,{throwIfNoEntry:false})?.isDirectory()){json(res,409,{error:'backup_folder_not_available'});return true}
   const error=await shell.openPath(folder);json(res,error?500:200,{ok:!error,error:error||null});return true;
  }
  if(route==='/desktop/ui-update/status'&&req.method==='GET'){
   json(res,200,{installedBuild:store.get('uiBuild')||null,appliedAt:store.get('uiAppliedAt')||null,lastCheckedAt:store.get('uiLastCheckedAt')||null,error:store.get('updateError')||null});return true;
  }
  if(route==='/desktop/ui-update/check'&&req.method==='POST'){
   json(res,200,await applyUiNow());return true;
  }
  if(route==='/desktop/app-update/status'&&req.method==='GET'){
   json(res,200,{version:app.getVersion(),signed:!!require('./release-config.json').signed,state:appUpdateState,updateReady});return true;
  }
  if(route==='/desktop/app-update/check'&&req.method==='POST'){
   const result=await checkAppUpdate();json(res,200,result);return true;
  }
  if(route==='/desktop/app-update/install'&&req.method==='POST'){
   if(!autoUpdater||!require('./release-config.json').signed||!updateReady){json(res,409,{error:'no_verified_update_ready'});return true}
   if(store.rows().some(row=>row.state==='pending'||row.state==='conflict')){json(res,409,{error:'sync_pending',message:'ابتدا عملیات همگام‌نشده را تکمیل کنید.'});return true}
   json(res,200,{ok:true,state:'installing'});setTimeout(()=>autoUpdater.quitAndInstall(false,true),250).unref();return true;
  }
  json(res,404,{error:'desktop_utility_not_found'});return true;
 };
 server=createHost({store,sync,request,token,roots:()=>[activeUiRoot,bundled].filter(Boolean),printCommitment,desktopUtilities,onLogin:async()=>{
   await sync.pause();
   const authResponse=await request('/api/auth/me');if(!authResponse.ok)throw Error('login_failed');const auth=await authResponse.json();
   // Never attach previous shop's operation receipts to another account's initial snapshot.
   const response=await request('/api/rental/desktop/snapshot');if(!response.ok)throw Error('server_desktop_update_required');
   const snapshot=await response.json();
   const claimed=auth?.rentalShop?.id||auth?.shop?.id||auth?.shopId||null;
   if(!snapshot.shopId||typeof snapshot.shopId!=='string'||(claimed&&String(claimed)!==snapshot.shopId))throw Error('snapshot_account_mismatch');
   store.changeAccount(snapshot.shopId,auth);sync.acceptSnapshot(snapshot);
   sync.report=null;sync.online=true;sync.resume();await sync.run();
   // Financial backups are never created without the explicit user action.
 },onLogout:async()=>{authEpoch++;return require('./session.cjs').logout(store,sync)}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));origin='http://127.0.0.1:'+server.address().port;
 win=new BrowserWindow({width:1440,height:950,minWidth:1000,minHeight:650,backgroundColor:'#f5f7fb',title:'PhotoBridge Store',icon:path.join(__dirname,'assets','photobridge.png'),show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,spellcheck:false}});
 win.removeMenu();win.once('ready-to-show',()=>{if(!process.argv.includes('--background'))win.show()});win.on('close',e=>{if(!quitting){e.preventDefault();win.hide()}});
 win.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith(origin+'/')){e.preventDefault();if(url.startsWith('https://'))void shell.openExternal(url)}});
 win.webContents.setWindowOpenHandler(({url})=>url==='about:blank'?{action:'allow',overrideBrowserWindowOptions:{webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}}}:(url.startsWith('https://')&&void shell.openExternal(url),{action:'deny'}));
 win.webContents.session.setPermissionRequestHandler((_wc,_permission,callback)=>callback(false));
 tray=new Tray(path.join(__dirname,'assets','photobridge.png'));tray.setToolTip('PhotoBridge Store · فعال در پس‌زمینه');tray.on('double-click',show);tray.setContextMenu(Menu.buildFromTemplate([{label:'باز کردن فوتوبریج',click:show},{label:'همگام‌سازی',click:()=>void sync.run()},{label:'پشتیبان‌گیری از اطلاعات',click:()=>void makeBackup()},{label:'بکاپ امور مالی',click:()=>void makeFinancialBackup()},{label:'تغییر آدرس سرور',click:()=>void configure()},{type:'separator'},{label:'خروج کامل (توقف اعلان‌ها)',click:()=>{quitting=true;app.quit()}}]));
 async function configure(){if(store.get('shopId')){dialog.showMessageBox(win,{message:'برای تغییر سرور ابتدا همگام‌سازی را کامل کن و از حساب خارج شو.'});return}const choice=await dialog.showOpenDialog(win,{title:'انتخاب فایل server.json شامل serverUrl',properties:['openFile'],filters:[{name:'JSON',extensions:['json']}]});if(choice.canceled)return;const config=JSON.parse(fs.readFileSync(choice.filePaths[0],'utf8')),u=new URL(config.serverUrl);if(u.protocol!=='https:'||u.username||u.password||u.pathname!=='/')throw Error('HTTPS server origin required');base=u.origin;store.set('serverUrl',base);store.set('cookie',null);win.reload()}
 async function makeBackup(){const folder=path.join(dir,'backups');fs.mkdirSync(folder,{recursive:true});await backup(store.db,path.join(folder,'store-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite'));const files=fs.readdirSync(folder).sort();for(const name of files.slice(0,-14))fs.unlinkSync(path.join(folder,name))}
 async function makeFinancialBackup(){
  try{
   if(!store.get('auth')||!store.snapshot())throw Error('login_required');
   const shopId=String(store.get('shopId')||'');
   let folder=store.get('financeBackupFolder:'+shopId);
   if(!folder){const pick=await dialog.showOpenDialog(win,{title:'انتخاب پوشه بکاپ مالی',properties:['openDirectory','createDirectory']});if(pick.canceled||!pick.filePaths?.[0])return null;folder=path.resolve(pick.filePaths[0]);store.set('financeBackupFolder:'+shopId,folder)}
   const result=finance.createFolderFinanceBackup({store,folder});
   await dialog.showMessageBox(win,{type:'info',message:'بکاپ امور مالی ذخیره شد.',detail:'پوشه: '+folder+'\nفایل بکاپ: '+result.jsonFile+'\nفایل بازکردن بکاپ: '+result.viewerFile,buttons:['تأیید','باز کردن پوشه'],defaultId:0}).then(answer=>{if(answer.response===1)void shell.openPath(folder)});
   return result;
  }catch(e){await dialog.showMessageBox(win,{type:'warning',message:'بکاپ مالی انجام نشد.',detail:String(e.message||e)});return null}
 }
 await applyUi(true);app.setLoginItemSettings({openAtLogin:true,args:['--background']});if(process.argv.includes('--background'))win.hide();
 if(!store.get('auth'))await sync.pause();await sync.run();setInterval(()=>{if(store.get('auth'))void sync.run()},30000).unref();void makeBackup().catch(e=>store.set('backupError',e.message));setInterval(()=>void makeBackup().catch(()=>{}),86400000).unref();
 // No automatic finance backups: folder selection and manual button only.
 // Native EXE updates and website UI updates are different channels.
 // The NSIS feed must contain a properly published latest.yml + installer.
 // Do not install arbitrary downloaded EXEs from an unsigned feed.
 try{
  const updater=require('electron-updater').autoUpdater;
  autoUpdater=updater;updater.autoDownload=true;updater.autoInstallOnAppQuit=false;
  updater.on('update-available',()=>{appUpdateState='downloading'});
  updater.on('update-not-available',()=>{appUpdateState='current'});
  updater.on('error',e=>{appUpdateState='error:'+String(e.message||e);store.set('appUpdateError',String(e.message||e))});
  updater.on('update-downloaded',()=>{updateReady=true;appUpdateState='ready';new Notification({title:'PhotoBridge Store',body:'نسخه جدید برنامه آماده نصب است. از تنظیمات «نصب آپدیت برنامه» را بزنید.'}).show()});
  checkAppUpdate=async()=>{
   if(!app.isPackaged)return {ok:false,state:'installer_required',message:'در حالت توسعه امکان آپدیت نصب‌کننده وجود ندارد.'};
   if(!require('./release-config.json').signed)return {ok:false,state:'unsigned_test_build',message:'برای آپدیت خودکار، نسخه رسمی امضاشده و انتشار آخرین نسخه روی سرور لازم است.'};
   try{appUpdateState='checking';const info=await updater.checkForUpdates();return {ok:true,state:appUpdateState,version:info?.updateInfo?.version||null}}
   catch(e){appUpdateState='error:'+String(e.message||e);return {ok:false,state:'update_check_failed',message:String(e.message||e)}}
  };
  if(app.isPackaged&&require('./release-config.json').signed){void checkAppUpdate();setInterval(()=>void checkAppUpdate(),6*3600000).unref()}
 }catch(e){appUpdateState='unavailable';store.set('appUpdateError',e.message)}
 async function applyUi(initial=false){
  const next=store.get('uiRoot'),exists=root=>{try{return Boolean(root&&fs.existsSync(path.join(root,'equipment-rental-portal.html')))}catch{return false}};
  if(!initial&&(!next||next===activeUiRoot))return true;
  const before=exists(activeUiRoot)?activeUiRoot:null,installedBuild=(()=>{try{return fs.readFileSync(path.join(bundled,'bundled-version.txt'),'utf8').trim()}catch{return null}})();const candidate=exists(next)&&(!installedBuild||installedBuild===store.get('bundledVersion'))?next:(before||bundled),failedBuild=store.get('uiBuild')||null;
  if(!initial&&candidate===activeUiRoot)return true;activeUiRoot=candidate;
  try{await win.loadURL(origin+'/start?token='+token);if(initial)store.set('bundledVersion',installedBuild);store.set('uiKnownGoodRoot',candidate);store.set('uiKnownGoodBuild',store.get('uiBuild')||null);store.set('uiAppliedAt',new Date().toISOString());store.set('uiFailedBuild',null);store.set('updateError',null);return true}
  catch(e){if(candidate!==bundled&&failedBuild)store.set('uiFailedBuild',failedBuild);store.set('updateError','ui_activation_failed:'+String(e.message||e));const previous=store.get('uiPreviousRoot'),known=store.get('uiKnownGoodRoot'),fallback=[before,previous,known,bundled].find(root=>root!==candidate&&exists(root));if(!fallback)throw e;activeUiRoot=fallback;store.set('uiRoot',fallback);let fallbackBuild=null;if(fallback===previous)fallbackBuild=store.get('uiPreviousBuild')||null;else if(fallback===known)fallbackBuild=store.get('uiKnownGoodBuild')||null;store.set('uiBuild',fallbackBuild);await win.loadURL(origin+'/start?token='+token);return false}
 }
 async function mayRefreshUi(){
  if(!win||win.isDestroyed()||!win.isVisible())return true;
  try{return await win.webContents.executeJavaScript(`!document.querySelector('[aria-modal="true"],.pbStoreNativeShade:not([hidden]),dialog[open]') && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)`)}catch{return false}
 }
 async function updateUi(startup=false){if(uiChecking)return false;uiChecking=true;try{
  const changed=await require('./ui-update.cjs').updateUi({store,request,bundled,directory:path.join(dir,'ui'),timeout:startup?90000:180000});
  if((changed||store.get('uiRoot')!==activeUiRoot)&&!startup){if(await mayRefreshUi())await applyUi(false);else new Notification({title:'PhotoBridge Store',body:'سایت به‌روزرسانی شد. برای اعمال بدون از دست رفتن فرم‌های باز، از تنظیمات «اعمال نسخه سایت» را بزنید.'}).show()}
  return changed;
 }catch(e){store.set('updateError',e.message);return false}finally{uiChecking=false}}
 applyUiNow=async()=>{
  const changed=await updateUi(true);
  if(!(await mayRefreshUi()))return {ok:true,changed,state:'ready_after_form_close'};
  const applied=await applyUi(false);
  return {ok:applied,changed,state:applied?'applied':'apply_failed'};
 };
 reopen=async()=>{await updateUi(true);await applyUi(false)};
 void updateUi();setInterval(()=>void updateUi(),10*60000).unref();
}
