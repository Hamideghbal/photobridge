@echo off
setlocal
cd /d "%~dp0"
call npm ci
if errorlevel 1 goto :failed
call npm test
if errorlevel 1 goto :failed
call npm run dist:unsigned
if errorlevel 1 goto :failed
echo.
echo SUCCESS: release\PhotoBridge-Lab-Setup-1.0.22-x64.exe
pause
exit /b 0
:failed
echo.
echo STOP: build did not complete. No tested installer was produced.
pause
exit /b 1
